# PGRI ATTENDANCE
### Sistem Daftar Hadir Online PGRI Berbasis Barcode & QR Code

Aplikasi sistem daftar hadir online resmi untuk organisasi **Persatuan Guru Republik Indonesia (PGRI)**. Dirancang khusus untuk kemudahan, kecepatan, dan keandalan saat kegiatan seminar, rapat pleno, konferensi cabang, workshop, maupun apel akbar PGRI.

---

## 🌟 Fitur Utama

1. **Autentikasi Admin Resmi (Firebase Authentication)**
   - Login admin terlindungi dengan email dan password.
   - Hak akses eksklusif untuk membuat kegiatan, memantau daftar hadir, mengedit data keliru, dan mengunduh laporan.

2. **Manajemen Kegiatan PGRI**
   - Pembuatan kegiatan baru lengkap dengan nama acara, tanggal, waktu (WIB), lokasi, dan penyelenggara.
   - Status kegiatan fleksibel (**Aktif** / **Nonaktif**). Ketika ditutup, peserta tidak dapat lagi melakukan absensi.

3. **QR Code Otomatis & Dinamis**
   - Menghasilkan QR Code unik untuk setiap kegiatan tanpa aplikasi pihak ketiga.
   - Fitur **Download PNG resolusi tinggi**, **Print QR siap cetak/proyektor**, **Copy Link**, dan **Generate Ulang QR Token**.

4. **Halaman Absensi Peserta (Mobile-First Android)**
   - Akses instan cukup dengan memindai barcode/QR Code melalui kamera HP Android/iPhone.
   - Form sederhana dan jelas:
     - Nomor Peserta (validasi angka)
     - Nama Lengkap (minimal 3 karakter)
     - Asal Sekolah / Unit Kerja
     - Jabatan di PGRI (Ketua, Wakil Ketua, Sekretaris, Bendahara, Pengurus Cabang, Pengurus Ranting, Anggota, Guru, Kepala Sekolah, Pengawas, Lainnya)
   - Konfirmasi sukses instan dengan ringkasan tanpa membocorkan data peserta lain.

5. **Pencegahan Absensi Duplikat (Anti-Duplicate)**
   - Sistem memvalidasi kombinasi `eventId + nomor peserta`.
   - Menolak pengisian ganda dengan notifikasi: *«Anda sudah tercatat hadir pada kegiatan ini.»*
   - Dilengkapi proteksi anti-double click saat tombol ditekan (*«MENYIMPAN...»*).

6. **Penyimpanan Cloud Firestore Realtime**
   - Data tersimpan secara aman di Google Firebase Firestore.
   - Data tidak hilang meskipun browser ditutup, HP direstart, atau admin login dari komputer lain.
   - Pembaruan jumlah kehadiran secara *realtime live count* di dashboard admin.

7. **Dashboard & Statistik Administrasi**
   - Kartu statistik: Total Kegiatan, Total Peserta Hadir, Kehadiran Hari Ini, Kegiatan Aktif.
   - Tabel realtime peserta hadir.
   - Pencarian cepat (berdasarkan Nomor, Nama, Asal Sekolah, Jabatan).
   - Filter multikriteria (berdasarkan Kegiatan, Tanggal, Sekolah, Jabatan).
   - Pengurutan data (Sorting) interaktif.

8. **Laporan & Ekspor PDF Standar Resmi (jsPDF & AutoTable)**
   - Ekspor rekap kehadiran dalam ukuran **A4** profesional.
   - Kop resmi PGRI, informasi kegiatan, tabel bernomor urut rapi, dan kolom tanda tangan pengurus PGRI.
   - Otomatis membuat halaman lanjutan (multi-page) jika jumlah peserta banyak.
   - Fitur tambahan: Ekspor CSV.

---

## 🚀 Cara Menjalankan Aplikasi

### 1. Prasyarat
- Node.js (versi 18+)
- Koneksi Internet untuk menghubungkan ke Google Firebase

### 2. Instalasi Dependensi
```bash
npm install
```

### 3. Konfigurasi Firebase
Aplikasi ini menggunakan Google Firebase resmi.
1. Lihat panduan lengkap di file `FIREBASE_SETUP.md`.
2. Anda dapat mengisi konfigurasi di `src/firebase-config.ts` atau langsung melalui modal **Pengaturan Firebase** di pojok atas aplikasi.

### 4. Menjalankan Server Pengembangan (Dev)
```bash
npm run dev
```
Aplikasi akan aktif di `http://localhost:3000`.

### 5. Build untuk Produksi
```bash
npm run build
```

---

## 🔒 Keamanan Database (Firestore Rules)
Aturan keamanan Firestore telah disiapkan di file `firestore.rules`.
- Peserta hanya diperkenankan membuat catatan kehadiran pada kegiatan yang berstatus aktif.
- Peserta dilarang membaca data seluruh peserta lain.
- Admin memiliki otorisasi penuh untuk mengelola kegiatan dan kehadiran.

---

## 📱 Desain & Identitas Visual
- **Warna Utama**: Merah PGRI (identitas semangat perjuangan guru Indonesia).
- **Aksen**: Putih, abu-abu netral, dan sentuhan emas/gold.
- **Antarmuka**: Responsif, tombol besar ramah sentuhan layar HP, kontras jelas, dan bahasa Indonesia baku yang ramah pengguna.

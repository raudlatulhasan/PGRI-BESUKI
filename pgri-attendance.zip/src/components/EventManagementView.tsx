import React, { useState, useEffect } from 'react';
import { 
  Calendar, 
  PlusCircle, 
  QrCode, 
  Users, 
  Trash2, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  MapPin, 
  Building2, 
  Power,
  Share2
} from 'lucide-react';
import { PGRIEvent } from '../types';
import { subscribeToEvents, updateEvent, deleteEvent } from '../services/eventService';
import { ShareBarcodeModal } from './ShareBarcodeModal';

interface Props {
  onCreateEventClick: () => void;
  onSelectEventForQr: (event: PGRIEvent) => void;
  onSelectEventForAttendance: (eventId: string) => void;
}

export const EventManagementView: React.FC<Props> = ({ 
  onCreateEventClick, 
  onSelectEventForQr, 
  onSelectEventForAttendance 
}) => {
  const [events, setEvents] = useState<PGRIEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [sharingEvent, setSharingEvent] = useState<PGRIEvent | null>(null);

  useEffect(() => {
    const unsubscribe = subscribeToEvents((data) => {
      setEvents(data);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleToggleStatus = async (event: PGRIEvent) => {
    const newStatus = event.status === 'Aktif' ? 'Nonaktif' : 'Aktif';
    const message = newStatus === 'Nonaktif' 
      ? `Tutup pendaftaran absensi untuk "${event.namaKegiatan}"? Peserta tidak akan bisa mengisi formulir lagi.`
      : `Buka kembali absensi untuk "${event.namaKegiatan}"?`;

    if (window.confirm(message)) {
      try {
        await updateEvent(event.id, { status: newStatus });
      } catch (err) {
        console.error("Gagal mengubah status kegiatan:", err);
        alert("Gagal mengubah status kegiatan.");
      }
    }
  };

  const handleDelete = async (event: PGRIEvent) => {
    if (window.confirm(`Hapus kegiatan "${event.namaKegiatan}" beserta seluruh data kehadirannya? Tindakan ini tidak dapat dibatalkan.`)) {
      try {
        await deleteEvent(event.id);
      } catch (err) {
        console.error("Gagal menghapus:", err);
        alert("Gagal menghapus kegiatan.");
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl shadow-xs border border-gray-200">
        <div>
          <h2 className="text-lg font-bold text-gray-900">Manajemen Kegiatan PGRI</h2>
          <p className="text-xs text-gray-500">Kelola agenda acara, status pembukaan absensi, dan barcode kehadiran</p>
        </div>

        <button
          onClick={onCreateEventClick}
          className="px-5 py-2.5 bg-red-700 hover:bg-red-800 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md transition-colors flex items-center gap-2 self-start sm:self-auto"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Buat Kegiatan Baru</span>
        </button>
      </div>

      {/* Events List */}
      {loading ? (
        <div className="bg-white rounded-2xl p-12 text-center text-gray-500 border border-gray-200">
          <div className="w-8 h-8 border-4 border-red-700 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
          <p className="text-xs font-semibold">Memuat daftar kegiatan...</p>
        </div>
      ) : events.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center text-gray-400 border border-gray-200">
          <Calendar className="w-12 h-12 mx-auto text-gray-300 mb-3" />
          <h3 className="text-base font-bold text-gray-700">Belum Ada Kegiatan</h3>
          <p className="text-xs text-gray-400 mt-1">Mulai dengan membuat agenda kegiatan PGRI pertama Anda.</p>
          <button
            onClick={onCreateEventClick}
            className="mt-4 px-5 py-2 bg-red-700 text-white text-xs font-bold rounded-xl hover:bg-red-800"
          >
            Buat Kegiatan Baru
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {events.map((event) => (
            <div
              key={event.id}
              className="bg-white rounded-2xl p-5 border border-gray-200 shadow-xs hover:border-red-200 transition-all flex flex-col md:flex-row md:items-center justify-between gap-4"
            >
              <div className="space-y-2 flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold flex items-center gap-1 ${
                    event.status === 'Aktif' 
                      ? 'bg-emerald-100 text-emerald-800' 
                      : 'bg-gray-200 text-gray-700'
                  }`}>
                    {event.status === 'Aktif' ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Absensi Aktif</span>
                      </>
                    ) : (
                      <>
                        <XCircle className="w-3.5 h-3.5 text-gray-500" />
                        <span>Absensi Nonaktif</span>
                      </>
                    )}
                  </span>

                  <span className="text-[11px] font-mono text-gray-400">
                    Token: <strong className="text-gray-600">{event.qrToken}</strong>
                  </span>
                </div>

                <h3 className="text-base sm:text-lg font-bold text-gray-900 leading-snug">
                  {event.namaKegiatan}
                </h3>

                <div className="flex flex-wrap gap-x-5 gap-y-1 text-xs text-gray-500">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-gray-400" />
                    {event.tanggal} • {event.waktu}
                  </span>
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-gray-400" />
                    {event.lokasi}
                  </span>
                  <span className="flex items-center gap-1">
                    <Building2 className="w-3.5 h-3.5 text-gray-400" />
                    {event.penyelenggara}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 shrink-0 border-t md:border-t-0 pt-3 md:pt-0">
                <button
                  onClick={() => setSharingEvent(event)}
                  className="px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs"
                  title="Bagikan Barcode & Link ke Peserta"
                >
                  <Share2 className="w-4 h-4" />
                  <span>Bagikan Barcode</span>
                </button>

                <button
                  onClick={() => onSelectEventForQr(event)}
                  className="px-3 py-2 bg-gray-50 hover:bg-gray-100 border border-gray-300 text-gray-700 hover:text-red-700 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
                  title="Lihat & Download QR Code"
                >
                  <QrCode className="w-4 h-4 text-red-700" />
                  <span>QR Code</span>
                </button>

                <button
                  onClick={() => onSelectEventForAttendance(event.id)}
                  className="px-3 py-2 bg-red-700 hover:bg-red-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs"
                  title="Lihat Daftar Kehadiran Peserta"
                >
                  <Users className="w-4 h-4" />
                  <span>Peserta</span>
                </button>

                <button
                  onClick={() => handleToggleStatus(event)}
                  className={`p-2 rounded-xl border text-xs font-semibold transition-colors ${
                    event.status === 'Aktif'
                      ? 'border-amber-300 bg-amber-50 text-amber-800 hover:bg-amber-100'
                      : 'border-emerald-300 bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
                  }`}
                  title={event.status === 'Aktif' ? 'Tutup Absensi' : 'Aktifkan Absensi'}
                >
                  <Power className="w-4 h-4" />
                </button>

                <button
                  onClick={() => handleDelete(event)}
                  className="p-2 border border-gray-200 text-gray-400 hover:text-red-700 hover:bg-red-50 rounded-xl transition-colors"
                  title="Hapus Kegiatan"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Share Barcode Modal */}
      {sharingEvent && (
        <ShareBarcodeModal
          isOpen={Boolean(sharingEvent)}
          event={sharingEvent}
          onClose={() => setSharingEvent(null)}
        />
      )}
    </div>
  );
};

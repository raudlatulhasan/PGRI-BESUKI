import React, { useState, useEffect } from 'react';
import { 
  Calendar, 
  Users, 
  UserCheck, 
  CheckCircle2, 
  PlusCircle, 
  QrCode, 
  FileText, 
  ArrowRight, 
  Activity, 
  Clock,
  MapPin,
  TrendingUp,
  Share2
} from 'lucide-react';
import { PGRIEvent, AttendanceRecord, ActiveTab } from '../types';
import { getEvents, subscribeToEvents } from '../services/eventService';
import { getAllAttendanceRecords, formatIndonesianDate } from '../services/attendanceService';
import { ShareBarcodeModal } from './ShareBarcodeModal';

interface Props {
  onNavigateTab: (tab: ActiveTab) => void;
  onSelectEventForQr: (event: PGRIEvent) => void;
  onSelectEventForAttendance: (eventId: string) => void;
}

export const AdminDashboard: React.FC<Props> = ({ 
  onNavigateTab, 
  onSelectEventForQr, 
  onSelectEventForAttendance 
}) => {
  const [events, setEvents] = useState<PGRIEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [totalAttendanceCount, setTotalAttendanceCount] = useState(0);
  const [todayAttendanceCount, setTodayAttendanceCount] = useState(0);
  const [recentRecords, setRecentRecords] = useState<{ event: PGRIEvent; record: AttendanceRecord }[]>([]);
  const [sharingEvent, setSharingEvent] = useState<PGRIEvent | null>(null);

  const todayStr = formatIndonesianDate(new Date());

  useEffect(() => {
    setLoading(true);

    const unsubscribe = subscribeToEvents(async (loadedEvents) => {
      setEvents(loadedEvents);

      // Calculate total attendance & today's attendance across all events
      let totalCount = 0;
      let todayCount = 0;
      const combinedRecent: { event: PGRIEvent; record: AttendanceRecord }[] = [];

      for (const ev of loadedEvents) {
        try {
          const records = await getAllAttendanceRecords(ev.id);
          totalCount += records.length;
          
          for (const rec of records) {
            if (rec.tanggalHadir === todayStr) {
              todayCount++;
            }
            combinedRecent.push({ event: ev, record: rec });
          }
        } catch {
          // Continue loop
        }
      }

      // Sort recent records descending
      combinedRecent.sort((a, b) => new Date(b.record.createdAt).getTime() - new Date(a.record.createdAt).getTime());

      setTotalAttendanceCount(totalCount);
      setTodayAttendanceCount(todayCount);
      setRecentRecords(combinedRecent.slice(0, 6));
      setLoading(false);
    });

    return () => unsubscribe();
  }, [todayStr]);

  const activeEventsCount = events.filter(e => e.status === 'Aktif').length;

  return (
    <div className="space-y-6">
      {/* Top Welcome Banner */}
      <div className="bg-gradient-to-r from-red-700 via-red-800 to-red-900 rounded-2xl p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <span className="px-3 py-1 bg-white/20 backdrop-blur-xs text-red-100 rounded-full text-xs font-bold tracking-wider uppercase inline-block mb-3">
            DASHBOARD ADMIN PGRI
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Selamat Datang di Panel PGRI ATTENDANCE
          </h1>
          <p className="mt-2 text-red-100 text-sm sm:text-base leading-relaxed">
            Pantau kehadiran guru dan anggota PGRI secara realtime, buat barcode kegiatan otomatis, serta unduh rekap kehadiran resmi format PDF.
          </p>
          <div className="mt-5 flex flex-wrap gap-3">
            <button
              onClick={() => onNavigateTab('create-event')}
              className="px-4 py-2.5 bg-white text-red-800 hover:bg-red-50 rounded-xl text-xs sm:text-sm font-bold shadow-md transition-all flex items-center gap-2"
            >
              <PlusCircle className="w-4 h-4 text-red-700" />
              <span>Buat Kegiatan Baru</span>
            </button>
            <button
              onClick={() => onNavigateTab('qrcode')}
              className="px-4 py-2.5 bg-red-950/70 hover:bg-red-950 text-white rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center gap-2 border border-red-500/30"
            >
              <QrCode className="w-4 h-4 text-amber-300" />
              <span>Tampilkan QR Code</span>
            </button>
          </div>
        </div>

        {/* Decorative background shape */}
        <div className="absolute right-0 bottom-0 translate-x-10 translate-y-10 w-72 h-72 bg-white/5 rounded-full pointer-events-none" />
      </div>

      {/* STATISTIC CARDS (4 CARDS AS REQUIRED BY BRIEF) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* TOTAL KEGIATAN */}
        <div className="bg-white p-5 rounded-2xl shadow-xs border border-gray-200 flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
              TOTAL KEGIATAN
            </p>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-gray-900 mt-1">
              {loading ? '-' : events.length}
            </h3>
            <p className="text-[11px] text-gray-400 mt-1">Agenda terdaftar di sistem</p>
          </div>
          <div className="w-12 h-12 bg-red-50 text-red-700 rounded-xl flex items-center justify-center">
            <Calendar className="w-6 h-6" />
          </div>
        </div>

        {/* TOTAL PESERTA HADIR */}
        <div className="bg-white p-5 rounded-2xl shadow-xs border border-gray-200 flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
              TOTAL PESERTA HADIR
            </p>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-gray-900 mt-1">
              {loading ? '-' : totalAttendanceCount}
            </h3>
            <p className="text-[11px] text-emerald-600 font-medium mt-1 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              Presensi tercatat di database
            </p>
          </div>
          <div className="w-12 h-12 bg-emerald-50 text-emerald-700 rounded-xl flex items-center justify-center">
            <Users className="w-6 h-6" />
          </div>
        </div>

        {/* KEHADIRAN HARI INI */}
        <div className="bg-white p-5 rounded-2xl shadow-xs border border-gray-200 flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
              KEHADIRAN HARI INI
            </p>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-gray-900 mt-1">
              {loading ? '-' : todayAttendanceCount}
            </h3>
            <p className="text-[11px] text-gray-400 mt-1">{todayStr}</p>
          </div>
          <div className="w-12 h-12 bg-blue-50 text-blue-700 rounded-xl flex items-center justify-center">
            <UserCheck className="w-6 h-6" />
          </div>
        </div>

        {/* KEGIATAN AKTIF */}
        <div className="bg-white p-5 rounded-2xl shadow-xs border border-gray-200 flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
              KEGIATAN AKTIF
            </p>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-gray-900 mt-1">
              {loading ? '-' : activeEventsCount}
            </h3>
            <p className="text-[11px] text-amber-600 font-medium mt-1">
              {activeEventsCount > 0 ? 'Siap menerima scan QR' : 'Belum ada agenda aktif'}
            </p>
          </div>
          <div className="w-12 h-12 bg-amber-50 text-amber-700 rounded-xl flex items-center justify-center">
            <Activity className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Grid: Active Events & Recent Attendance */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Active Events Column (2 cols) */}
        <div className="lg:col-span-2 bg-white rounded-2xl shadow-xs border border-gray-200 p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-gray-100">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-red-700" />
              <h2 className="text-base font-bold text-gray-900">Agenda Kegiatan PGRI</h2>
            </div>
            <button
              onClick={() => onNavigateTab('events')}
              className="text-xs font-bold text-red-700 hover:text-red-900 flex items-center gap-1"
            >
              <span>Kelola Semua</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {events.length === 0 ? (
            <div className="text-center py-10 text-gray-500">
              <Calendar className="w-10 h-10 mx-auto text-gray-300 mb-2" />
              <p className="text-sm font-semibold">Belum ada kegiatan yang dibuat</p>
              <button
                onClick={() => onNavigateTab('create-event')}
                className="mt-3 px-4 py-2 bg-red-700 text-white text-xs font-bold rounded-lg hover:bg-red-800"
              >
                Buat Kegiatan Pertama
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {events.slice(0, 4).map((ev) => (
                <div 
                  key={ev.id}
                  className="p-4 rounded-xl border border-gray-100 hover:border-red-200 hover:shadow-xs transition-all bg-gray-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        ev.status === 'Aktif' 
                          ? 'bg-emerald-100 text-emerald-800' 
                          : 'bg-gray-200 text-gray-700'
                      }`}>
                        {ev.status}
                      </span>
                      <h3 className="font-bold text-gray-900 text-sm sm:text-base">
                        {ev.namaKegiatan}
                      </h3>
                    </div>
                    <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-gray-500">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-gray-400" />
                        {ev.tanggal} • {ev.waktu}
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-gray-400" />
                        {ev.lokasi}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => setSharingEvent(ev)}
                      className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs"
                      title="Bagikan Barcode Kegiatan"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                      <span>Bagikan</span>
                    </button>
                    <button
                      onClick={() => {
                        onSelectEventForQr(ev);
                        onNavigateTab('qrcode');
                      }}
                      className="px-3 py-1.5 bg-white border border-gray-300 hover:border-red-600 text-gray-700 hover:text-red-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
                      title="Lihat QR Code"
                    >
                      <QrCode className="w-3.5 h-3.5" />
                      <span>QR</span>
                    </button>
                    <button
                      onClick={() => {
                        onSelectEventForAttendance(ev.id);
                        onNavigateTab('attendance-list');
                      }}
                      className="px-3 py-1.5 bg-red-700 hover:bg-red-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors"
                      title="Lihat Peserta"
                    >
                      <Users className="w-3.5 h-3.5" />
                      <span>Peserta</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent Attendance Column (1 col) */}
        <div className="bg-white rounded-2xl shadow-xs border border-gray-200 p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-gray-100">
            <div className="flex items-center gap-2">
              <UserCheck className="w-5 h-5 text-emerald-700" />
              <h2 className="text-base font-bold text-gray-900">Kehadiran Terbaru</h2>
            </div>
            <button
              onClick={() => onNavigateTab('attendance-list')}
              className="text-xs font-bold text-red-700 hover:text-red-900"
            >
              Lihat Semua
            </button>
          </div>

          {recentRecords.length === 0 ? (
            <div className="text-center py-10 text-gray-400">
              <Users className="w-8 h-8 mx-auto mb-2 text-gray-300" />
              <p className="text-xs">Belum ada aktivitas presensi masuk</p>
            </div>
          ) : (
            <div className="space-y-3">
              {recentRecords.map(({ event, record }) => (
                <div key={record.id} className="p-3 bg-gray-50 rounded-xl border border-gray-100 space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-gray-900 truncate pr-2">{record.nama}</span>
                    <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded shrink-0">
                      {record.waktuHadir}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-gray-500">
                    <span className="truncate">{record.asalSekolah}</span>
                    <span className="font-medium text-gray-700">{record.jabatanPGRI}</span>
                  </div>
                  <div className="text-[10px] text-gray-400 truncate pt-1 border-t border-gray-200">
                    {event.namaKegiatan}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Share Barcode Modal */}
      {sharingEvent && (
        <ShareBarcodeModal
          isOpen={Boolean(sharingEvent)}
          event={sharingEvent}
          onClose={() => setSharingEvent(null)}
        />
      )}
    </div>
  );
};

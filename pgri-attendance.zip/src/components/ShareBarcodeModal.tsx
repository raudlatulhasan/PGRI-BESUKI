import React, { useState, useEffect } from 'react';
import { 
  X, 
  Download, 
  Copy, 
  Check, 
  Printer, 
  ExternalLink, 
  Share2, 
  Maximize2, 
  Calendar, 
  MapPin, 
  Building2,
  Clock,
  Sparkles
} from 'lucide-react';
import { PGRIEvent } from '../types';
import { generateQrDataUrl, getAttendanceUrl } from '../services/qrService';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  event: PGRIEvent | null;
}

export const ShareBarcodeModal: React.FC<Props> = ({ isOpen, onClose, event }) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [fullscreenMode, setFullscreenMode] = useState<boolean>(false);

  useEffect(() => {
    if (!isOpen || !event) return;

    let isMounted = true;
    setLoading(true);
    const targetUrl = getAttendanceUrl(event);

    generateQrDataUrl(targetUrl)
      .then((url) => {
        if (isMounted) {
          setQrDataUrl(url);
          setLoading(false);
        }
      })
      .catch((err) => {
        console.error("Gagal generate QR Code:", err);
        if (isMounted) setLoading(false);
      });

    return () => { isMounted = false; };
  }, [isOpen, event]);

  if (!isOpen || !event) return null;

  const attendanceUrl = getAttendanceUrl(event);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(attendanceUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadPNG = () => {
    if (!qrDataUrl) return;
    const link = document.createElement('a');
    link.href = qrDataUrl;
    const sanitized = event.namaKegiatan.replace(/[^a-zA-Z0-9_-]/g, '_');
    link.download = `Barcode_Daftar_Hadir_${sanitized}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleShareWhatsApp = () => {
    const text = encodeURIComponent(
      `*DAFTAR HADIR ONLINE PGRI*\n` +
      `Kegiatan: *${event.namaKegiatan}*\n` +
      `Tanggal: ${event.tanggal} (${event.waktu})\n` +
      `Lokasi: ${event.lokasi}\n\n` +
      `Bapak/Ibu Pengurus dan Anggota PGRI yang hadir, silakan mengisi daftar hadir melalui link berikut:\n` +
      `${attendanceUrl}\n\n` +
      `_Persatuan Guru Republik Indonesia (PGRI)_`
    );
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  const handlePrint = () => {
    window.print();
  };

  // FULLSCREEN PROJECTOR / DISPLAY MODE
  if (fullscreenMode) {
    return (
      <div className="fixed inset-0 z-50 bg-white flex flex-col items-center justify-center p-6 text-center select-none">
        <button
          onClick={() => setFullscreenMode(false)}
          className="absolute top-6 right-6 px-4 py-2 bg-gray-900 text-white rounded-xl text-xs font-bold hover:bg-gray-800 transition-colors flex items-center gap-1.5 shadow-lg"
        >
          <X className="w-4 h-4" />
          <span>Keluar Layar Penuh</span>
        </button>

        <div className="max-w-2xl w-full">
          <div className="border-b-4 border-red-700 pb-4 mb-6">
            <span className="text-red-700 font-extrabold tracking-widest uppercase text-sm sm:text-lg">
              PERSATUAN GURU REPUBLIK INDONESIA (PGRI)
            </span>
            <h1 className="text-2xl sm:text-4xl font-black text-gray-900 mt-1">
              {event.namaKegiatan}
            </h1>
            <p className="text-sm sm:text-base text-gray-600 mt-1">
              {event.tanggal} &bull; {event.waktu} &bull; {event.lokasi}
            </p>
          </div>

          <div className="p-6 bg-white rounded-3xl shadow-2xl border-8 border-red-700 inline-block my-4">
            {qrDataUrl && (
              <img 
                src={qrDataUrl} 
                alt="Barcode Daftar Hadir"
                className="w-72 h-72 sm:w-96 sm:h-96 mx-auto object-contain"
              />
            )}
          </div>

          <div className="mt-4">
            <span className="px-6 py-2.5 bg-red-700 text-white rounded-full font-black text-base sm:text-xl tracking-wider uppercase shadow-md animate-pulse">
              PINDAI / SCAN DENGAN KAMERA HP ANDA
            </span>
            <p className="text-gray-500 text-xs sm:text-sm mt-3">
              Arahkan kamera HP Android/iPhone ke barcode di atas untuk mengisi daftar hadir kegiatan.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in">
      <div className="w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="px-6 py-4 bg-red-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-white/10 rounded-lg">
              <Share2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold">Bagikan Barcode Daftar Hadir</h2>
              <p className="text-xs text-red-100">Peserta cukup scan barcode untuk menuju link pengisian</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-white/20 transition-colors text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-center">
          
          {/* Event Information summary */}
          <div className="p-3.5 bg-red-50/60 border border-red-100 rounded-xl text-left space-y-1">
            <span className="text-[10px] font-bold text-red-700 uppercase tracking-wider block">
              Agenda Kegiatan
            </span>
            <h3 className="font-extrabold text-gray-900 text-sm sm:text-base">
              {event.namaKegiatan}
            </h3>
            <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-gray-600 pt-1">
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-red-700" />
                {event.tanggal} ({event.waktu})
              </span>
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-red-700" />
                {event.lokasi}
              </span>
            </div>
          </div>

          {/* Barcode / QR Image Container */}
          <div className="p-4 bg-white rounded-2xl border-4 border-red-700 shadow-lg inline-block">
            {loading ? (
              <div className="w-56 h-56 flex flex-col items-center justify-center">
                <div className="w-8 h-8 border-4 border-red-700 border-t-transparent rounded-full animate-spin mb-2" />
                <p className="text-xs text-gray-500 font-semibold">Menyiapkan Barcode...</p>
              </div>
            ) : qrDataUrl ? (
              <img 
                src={qrDataUrl} 
                alt={`Barcode Daftar Hadir ${event.namaKegiatan}`}
                className="w-56 h-56 sm:w-64 sm:h-64 mx-auto object-contain"
              />
            ) : (
              <p className="text-xs text-red-600">Gagal memuat barcode</p>
            )}
            <div className="mt-2 text-[11px] font-mono text-gray-500 font-semibold">
              SCAN UNTUK LINK DAFTAR HADIR
            </div>
          </div>

          {/* Direct Link box */}
          <div className="p-3 bg-gray-50 border border-gray-200 rounded-xl flex items-center justify-between gap-2 text-left">
            <div className="truncate text-xs font-mono text-gray-600 flex-1">
              {attendanceUrl}
            </div>
            <button
              onClick={handleCopyLink}
              className="px-3 py-1.5 bg-white border border-gray-300 hover:border-red-600 text-gray-700 hover:text-red-700 text-xs font-bold rounded-lg shrink-0 flex items-center gap-1"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-700">Tersalin</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Salin Link</span>
                </>
              )}
            </button>
          </div>

          {/* Action Sharing Buttons Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2">
            
            {/* Bagikan WhatsApp */}
            <button
              onClick={handleShareWhatsApp}
              className="p-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-colors shadow-xs"
            >
              <Share2 className="w-4 h-4" />
              <span>Kirim WhatsApp</span>
            </button>

            {/* Mode Proyektor */}
            <button
              onClick={() => setFullscreenMode(true)}
              className="p-2.5 bg-gray-900 hover:bg-black text-white rounded-xl text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-colors shadow-xs"
              title="Tampilkan barcode ukuran besar di proyektor atau TV aula"
            >
              <Maximize2 className="w-4 h-4 text-amber-300" />
              <span>Mode Proyektor</span>
            </button>

            {/* Download Gambar */}
            <button
              onClick={handleDownloadPNG}
              className="p-2.5 bg-red-700 hover:bg-red-800 text-white rounded-xl text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-colors shadow-xs"
            >
              <Download className="w-4 h-4" />
              <span>Download Barcode</span>
            </button>

            {/* Cetak Poster */}
            <button
              onClick={handlePrint}
              className="p-2.5 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-xl text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-colors border border-gray-300"
            >
              <Printer className="w-4 h-4" />
              <span>Cetak Poster</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-gray-50 border-t border-gray-100 flex items-center justify-between text-xs">
          <span className="text-gray-400">PGRI Attendance System</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-lg font-bold"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};

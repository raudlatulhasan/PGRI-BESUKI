import React, { useState } from 'react';
import { Calendar, Clock, MapPin, Building2, Save, ArrowLeft, CheckCircle2, AlertCircle } from 'lucide-react';
import { createEvent } from '../services/eventService';
import { PGRIEvent, EventStatus } from '../types';

interface Props {
  onEventCreated: (createdEvent: PGRIEvent) => void;
  onCancel: () => void;
}

export const CreateEventView: React.FC<Props> = ({ onEventCreated, onCancel }) => {
  const today = new Date().toISOString().split('T')[0];

  const [namaKegiatan, setNamaKegiatan] = useState('');
  const [tanggal, setTanggal] = useState(today);
  const [waktu, setWaktu] = useState('08:00 WIB');
  const [lokasi, setLokasi] = useState('');
  const [penyelenggara, setPenyelenggara] = useState('PGRI');
  const [status, setStatus] = useState<EventStatus>('Aktif');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!namaKegiatan.trim() || namaKegiatan.trim().length < 3) {
      setErrorMsg('Nama kegiatan wajib diisi minimal 3 karakter.');
      return;
    }
    if (!tanggal) {
      setErrorMsg('Tanggal kegiatan wajib dipilih.');
      return;
    }
    if (!waktu.trim()) {
      setErrorMsg('Waktu kegiatan wajib diisi (contoh: 08:00 WIB).');
      return;
    }
    if (!lokasi.trim()) {
      setErrorMsg('Lokasi kegiatan wajib diisi.');
      return;
    }
    if (!penyelenggara.trim()) {
      setErrorMsg('Penyelenggara wajib diisi.');
      return;
    }

    setIsSubmitting(true);

    try {
      const newEvent = await createEvent({
        namaKegiatan: namaKegiatan.trim(),
        tanggal,
        waktu: waktu.trim(),
        lokasi: lokasi.trim(),
        penyelenggara: penyelenggara.trim(),
        status
      });

      setIsSubmitting(false);
      onEventCreated(newEvent);
    } catch (err: unknown) {
      setIsSubmitting(false);
      console.error("Gagal menyimpan kegiatan:", err);
      setErrorMsg('Gagal menyimpan kegiatan ke database. Periksa koneksi internet atau konfigurasi Firebase.');
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
        
        {/* Header */}
        <div className="bg-red-700 text-white p-6 sm:p-7 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onCancel}
              className="p-1.5 rounded-lg hover:bg-white/20 transition-colors text-white"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h2 className="text-xl font-bold tracking-tight">Buat Kegiatan PGRI Baru</h2>
              <p className="text-xs text-red-100">Sistem otomatis membuat Token & Barcode QR Code presensi</p>
            </div>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 sm:p-7 space-y-5">
          {errorMsg && (
            <div className="p-3.5 bg-red-50 text-red-700 border border-red-200 rounded-xl text-xs sm:text-sm font-medium flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div>
            <label className="block text-xs sm:text-sm font-bold text-gray-800 mb-1">
              Nama Kegiatan <span className="text-red-600">*</span>
            </label>
            <input
              type="text"
              value={namaKegiatan}
              onChange={(e) => setNamaKegiatan(e.target.value)}
              placeholder="Contoh: Rapat Kerja PGRI Cabang Besuki"
              className="w-full px-4 py-2.5 text-sm border-2 border-gray-300 rounded-xl focus:border-red-600 focus:outline-hidden"
              required
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs sm:text-sm font-bold text-gray-800 mb-1">
                Tanggal Pelaksanaan <span className="text-red-600">*</span>
              </label>
              <div className="relative">
                <Calendar className="w-4 h-4 text-gray-400 absolute left-3.5 top-3.5" />
                <input
                  type="date"
                  value={tanggal}
                  onChange={(e) => setTanggal(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 text-sm border-2 border-gray-300 rounded-xl focus:border-red-600 focus:outline-hidden"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs sm:text-sm font-bold text-gray-800 mb-1">
                Waktu Acara <span className="text-red-600">*</span>
              </label>
              <div className="relative">
                <Clock className="w-4 h-4 text-gray-400 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  value={waktu}
                  onChange={(e) => setWaktu(e.target.value)}
                  placeholder="08:00 WIB"
                  className="w-full pl-10 pr-4 py-2.5 text-sm border-2 border-gray-300 rounded-xl focus:border-red-600 focus:outline-hidden"
                  required
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs sm:text-sm font-bold text-gray-800 mb-1">
              Lokasi / Tempat Acara <span className="text-red-600">*</span>
            </label>
            <div className="relative">
              <MapPin className="w-4 h-4 text-gray-400 absolute left-3.5 top-3.5" />
              <input
                type="text"
                value={lokasi}
                onChange={(e) => setLokasi(e.target.value)}
                placeholder="Contoh: Gedung Guru PGRI / Aula SMPN 1 Besuki"
                className="w-full pl-10 pr-4 py-2.5 text-sm border-2 border-gray-300 rounded-xl focus:border-red-600 focus:outline-hidden"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs sm:text-sm font-bold text-gray-800 mb-1">
                Penyelenggara
              </label>
              <div className="relative">
                <Building2 className="w-4 h-4 text-gray-400 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  value={penyelenggara}
                  onChange={(e) => setPenyelenggara(e.target.value)}
                  placeholder="PGRI Cabang Besuki"
                  className="w-full pl-10 pr-4 py-2.5 text-sm border-2 border-gray-300 rounded-xl focus:border-red-600 focus:outline-hidden"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs sm:text-sm font-bold text-gray-800 mb-1">
                Status Pembukaan Absensi
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as EventStatus)}
                className="w-full px-4 py-2.5 text-sm font-semibold bg-white border-2 border-gray-300 rounded-xl focus:border-red-600 focus:outline-hidden"
              >
                <option value="Aktif">Aktif (Peserta Dapat Mengisi)</option>
                <option value="Nonaktif">Nonaktif (Absensi Ditutup)</option>
              </select>
            </div>
          </div>

          <div className="pt-4 border-t border-gray-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onCancel}
              className="px-5 py-2.5 text-sm font-semibold text-gray-700 bg-white border border-gray-300 rounded-xl hover:bg-gray-100 transition-colors"
            >
              Batal
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2.5 bg-red-700 hover:bg-red-800 text-white font-bold rounded-xl shadow-md transition-colors flex items-center gap-2 text-sm disabled:bg-gray-400"
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>MENYIMPAN KEGIATAN...</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>SIMPAN KEGIATAN</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

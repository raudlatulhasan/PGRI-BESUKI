import React, { useState } from 'react';
import { X, Save, Edit3, School, User, Tag } from 'lucide-react';
import { AttendanceRecord } from '../types';
import { updateAttendanceRecord } from '../services/attendanceService';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  record: AttendanceRecord | null;
  onUpdated: () => void;
}

const JABATAN_OPTIONS = [
  'Ketua',
  'Wakil Ketua',
  'Sekretaris',
  'Bendahara',
  'Pengurus Cabang',
  'Pengurus Ranting',
  'Anggota',
  'Guru',
  'Kepala Sekolah',
  'Pengawas',
  'Lainnya'
];

export const EditAttendanceModal: React.FC<Props> = ({ 
  isOpen, 
  onClose, 
  record, 
  onUpdated 
}) => {
  if (!isOpen || !record) return null;

  const [nama, setNama] = useState(record.nama);
  const [asalSekolah, setAsalSekolah] = useState(record.asalSekolah);
  const [jabatan, setJabatan] = useState(record.jabatanPGRI);
  const [isSaving, setIsSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nama.trim() || nama.trim().length < 3) {
      setErrorMsg('Nama lengkap minimal 3 karakter.');
      return;
    }
    if (!asalSekolah.trim()) {
      setErrorMsg('Asal sekolah tidak boleh kosong.');
      return;
    }

    setIsSaving(true);
    try {
      await updateAttendanceRecord(record.eventId, record.id, {
        nama: nama.trim(),
        asalSekolah: asalSekolah.trim(),
        jabatanPGRI: jabatan.trim()
      });
      setIsSaving(false);
      onUpdated();
      onClose();
    } catch (err) {
      setIsSaving(false);
      console.error("Gagal mengupdate data kehadiran:", err);
      setErrorMsg('Gagal memperbarui data.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden">
        
        {/* Header */}
        <div className="px-6 py-4 bg-red-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Edit3 className="w-5 h-5" />
            <h3 className="font-bold text-base">Perbaiki Data Peserta Hadir</h3>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-white/20 rounded-lg text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSave} className="p-6 space-y-4 text-gray-700">
          {errorMsg && (
            <p className="text-xs text-red-600 bg-red-50 p-2.5 rounded-lg border border-red-200">
              {errorMsg}
            </p>
          )}

          <div>
            <label className="block text-xs font-bold text-gray-600 mb-1">
              Nomor Peserta (Permanen)
            </label>
            <input
              type="text"
              disabled
              value={record.nomor}
              className="w-full px-3 py-2 text-sm bg-gray-100 border border-gray-300 rounded-lg text-gray-500 font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1">
              Nama Lengkap Peserta
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={nama}
                onChange={(e) => setNama(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-600 focus:outline-hidden"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1">
              Asal Sekolah / Unit Kerja
            </label>
            <div className="relative">
              <School className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={asalSekolah}
                onChange={(e) => setAsalSekolah(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-600 focus:outline-hidden"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1">
              Jabatan
            </label>
            <div className="relative">
              <Tag className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={jabatan}
                onChange={(e) => setJabatan(e.target.value)}
                placeholder="Pilih atau ketik jabatan..."
                list="jabatan-list"
                className="w-full pl-9 pr-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-600 focus:outline-hidden"
                required
              />
              <datalist id="jabatan-list">
                {JABATAN_OPTIONS.map(j => (
                  <option key={j} value={j} />
                ))}
              </datalist>
            </div>
          </div>

          <div className="pt-3 border-t border-gray-100 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-gray-600 hover:bg-gray-100 rounded-lg"
            >
              Batal
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-5 py-2 text-xs font-bold text-white bg-red-700 hover:bg-red-800 rounded-lg shadow-sm flex items-center gap-1.5"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{isSaving ? 'Menyimpan...' : 'Simpan Perubahan'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

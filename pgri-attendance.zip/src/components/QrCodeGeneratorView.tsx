import React, { useState, useEffect } from 'react';
import { 
  QrCode, 
  Download, 
  Printer, 
  Copy, 
  RefreshCw, 
  Check, 
  Calendar, 
  MapPin, 
  ExternalLink, 
  Building2, 
  Sparkles,
  Maximize2,
  X
} from 'lucide-react';
import { PGRIEvent } from '../types';
import { generateQrDataUrl, getAttendanceUrl } from '../services/qrService';
import { regenerateQrToken, getEvents } from '../services/eventService';

interface Props {
  selectedEvent: PGRIEvent | null;
  onSelectEvent: (event: PGRIEvent) => void;
}

export const QrCodeGeneratorView: React.FC<Props> = ({ selectedEvent, onSelectEvent }) => {
  const [events, setEvents] = useState<PGRIEvent[]>([]);
  const [currentEvent, setCurrentEvent] = useState<PGRIEvent | null>(selectedEvent);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const [isRegenerating, setIsRegenerating] = useState<boolean>(false);
  const [loadingQr, setLoadingQr] = useState<boolean>(true);
  const [fullscreenMode, setFullscreenMode] = useState<boolean>(false);

  // Load events if not already selected
  useEffect(() => {
    getEvents().then(all => {
      setEvents(all);
      if (!currentEvent && all.length > 0) {
        setCurrentEvent(all[0]);
        onSelectEvent(all[0]);
      }
    });
  }, [currentEvent, onSelectEvent]);

  // Keep synced if prop changes
  useEffect(() => {
    if (selectedEvent) {
      setCurrentEvent(selectedEvent);
    }
  }, [selectedEvent]);

  // Generate QR image when currentEvent or qrToken changes
  useEffect(() => {
    if (!currentEvent) return;

    let isMounted = true;
    setLoadingQr(true);

    const targetUrl = getAttendanceUrl(currentEvent);
    generateQrDataUrl(targetUrl)
      .then((url) => {
        if (isMounted) {
          setQrDataUrl(url);
          setLoadingQr(false);
        }
      })
      .catch((err) => {
        console.error("Error creating QR Code:", err);
        if (isMounted) setLoadingQr(false);
      });

    return () => { isMounted = false; };
  }, [currentEvent?.id, currentEvent?.qrToken]);

  const handleCopyLink = () => {
    if (!currentEvent) return;
    const url = getAttendanceUrl(currentEvent);
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadPNG = () => {
    if (!qrDataUrl || !currentEvent) return;
    const link = document.createElement('a');
    link.href = qrDataUrl;
    const sanitized = currentEvent.namaKegiatan.replace(/[^a-zA-Z0-9_-]/g, '_');
    link.download = `QR_Absensi_${sanitized}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleRegenerateQr = async () => {
    if (!currentEvent) return;
    if (!window.confirm('Buat token QR Code baru? Barcode lama tidak akan berlaku lagi untuk absensi.')) {
      return;
    }

    setIsRegenerating(true);
    try {
      const newToken = await regenerateQrToken(currentEvent.id);
      const updatedEvent: PGRIEvent = { ...currentEvent, qrToken: newToken };
      setCurrentEvent(updatedEvent);
      onSelectEvent(updatedEvent);
    } catch (err) {
      console.error("Error regenerating QR:", err);
      alert("Gagal memperbarui token QR Code.");
    } finally {
      setIsRegenerating(false);
    }
  };

  if (!currentEvent) {
    return (
      <div className="bg-white rounded-2xl p-12 text-center border border-gray-200 shadow-xs">
        <QrCode className="w-12 h-12 mx-auto text-gray-300 mb-3" />
        <h3 className="text-lg font-bold text-gray-800">Pilih Kegiatan Terlebih Dahulu</h3>
        <p className="text-gray-500 text-sm mt-1">Belum ada kegiatan yang dipilih untuk pembuatan QR Code.</p>
      </div>
    );
  }

  const attendanceUrl = getAttendanceUrl(currentEvent);

  // Fullscreen Projector / Venue Screen Mode
  if (fullscreenMode) {
    return (
      <div className="fixed inset-0 z-50 bg-white flex flex-col items-center justify-center p-6 text-center select-none animate-in fade-in">
        <button
          onClick={() => setFullscreenMode(false)}
          className="absolute top-6 right-6 px-4 py-2 bg-gray-900 text-white rounded-xl text-xs font-bold hover:bg-gray-800 transition-colors flex items-center gap-1.5 shadow-lg"
        >
          <X className="w-4 h-4" />
          <span>Keluar Layar Penuh</span>
        </button>

        <div className="max-w-2xl w-full">
          <div className="border-b-4 border-red-700 pb-4 mb-6">
            <span className="text-red-700 font-extrabold tracking-widest uppercase text-sm sm:text-lg">
              PERSATUAN GURU REPUBLIK INDONESIA (PGRI)
            </span>
            <h1 className="text-2xl sm:text-4xl font-black text-gray-900 mt-1">
              {currentEvent.namaKegiatan}
            </h1>
            <p className="text-sm sm:text-base text-gray-600 mt-1">
              {currentEvent.tanggal} &bull; {currentEvent.waktu} &bull; {currentEvent.lokasi}
            </p>
          </div>

          <div className="p-6 bg-white rounded-3xl shadow-2xl border-8 border-red-700 inline-block my-4">
            {qrDataUrl && (
              <img 
                src={qrDataUrl} 
                alt="Barcode Daftar Hadir"
                className="w-72 h-72 sm:w-96 sm:h-96 mx-auto object-contain"
              />
            )}
          </div>

          <div className="mt-4">
            <span className="px-6 py-2.5 bg-red-700 text-white rounded-full font-black text-base sm:text-xl tracking-wider uppercase shadow-md animate-pulse">
              PINDAI / SCAN DENGAN KAMERA HP ANDA
            </span>
            <p className="text-gray-500 text-xs sm:text-sm mt-3">
              Arahkan kamera HP Android/iPhone ke barcode di atas untuk mengisi daftar hadir kegiatan.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      {/* Printable Poster Card */}
      <div className="bg-white rounded-2xl shadow-xl border-2 border-red-700/20 overflow-hidden text-center p-6 sm:p-10 relative">
        
        {/* Official Header */}
        <div className="border-b-2 border-red-700 pb-4 mb-6">
          <div className="flex items-center justify-center gap-2 mb-1">
            <span className="text-red-700 font-extrabold text-sm sm:text-base tracking-widest uppercase">
              PERSATUAN GURU REPUBLIK INDONESIA
            </span>
          </div>
          <h1 className="text-xl sm:text-3xl font-black text-gray-900 tracking-tight">
            QR CODE DAFTAR HADIR
          </h1>
          <p className="text-xs sm:text-sm text-gray-600 font-medium mt-1">
            Sistem Absensi Online Resmi Berbasis Barcode
          </p>
        </div>

        {/* Event Details Box */}
        <div className="bg-gray-50 rounded-xl p-4 mb-6 border border-gray-200 text-left max-w-lg mx-auto">
          <h2 className="text-base sm:text-lg font-bold text-red-800 text-center mb-3">
            {currentEvent.namaKegiatan}
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-gray-600">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-red-700 shrink-0" />
              <span>{currentEvent.tanggal} ({currentEvent.waktu})</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-red-700 shrink-0" />
              <span className="truncate">{currentEvent.lokasi}</span>
            </div>
            <div className="flex items-center gap-2 sm:col-span-2">
              <Building2 className="w-4 h-4 text-red-700 shrink-0" />
              <span>{currentEvent.penyelenggara}</span>
            </div>
          </div>
        </div>

        {/* QR CODE DISPLAY (BIG & CRISP) */}
        <div className="my-6 inline-block p-4 sm:p-6 bg-white rounded-3xl shadow-lg border-4 border-red-700 relative">
          {loadingQr ? (
            <div className="w-64 h-64 sm:w-80 sm:h-80 flex flex-col items-center justify-center">
              <div className="w-10 h-10 border-4 border-red-700 border-t-transparent rounded-full animate-spin mb-3" />
              <p className="text-xs text-gray-500 font-semibold">Menghasilkan Barcode...</p>
            </div>
          ) : qrDataUrl ? (
            <img 
              src={qrDataUrl} 
              alt={`QR Code Absensi ${currentEvent.namaKegiatan}`}
              className="w-64 h-64 sm:w-80 sm:h-80 mx-auto object-contain"
            />
          ) : (
            <p className="text-xs text-red-500">Gagal memuat QR Code</p>
          )}

          {/* Token badge */}
          <div className="mt-2 text-[11px] font-mono text-gray-400">
            Token: <span className="font-bold text-gray-700">{currentEvent.qrToken}</span>
          </div>
        </div>

        {/* Callout Instruction */}
        <div className="mb-6">
          <div className="inline-flex items-center gap-2 px-5 py-2 rounded-full bg-red-700 text-white font-extrabold text-sm sm:text-base tracking-wider uppercase shadow-md animate-pulse">
            <QrCode className="w-5 h-5" />
            <span>SCAN UNTUK DAFTAR HADIR</span>
          </div>
          <p className="text-xs text-gray-500 mt-2">
            Arahkan kamera HP Android/iPhone Anda ke barcode di atas untuk mengisi formulir kehadiran.
          </p>
        </div>

        {/* URL Box */}
        <div className="p-3 bg-gray-50 border border-gray-200 rounded-xl text-left max-w-lg mx-auto flex items-center justify-between gap-3 text-xs mb-6 print:hidden">
          <div className="truncate text-gray-600 font-mono">
            {attendanceUrl}
          </div>
          <a
            href={attendanceUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-red-700 font-bold hover:underline shrink-0 flex items-center gap-1"
          >
            <span>Buka Form</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>

        {/* ACTION BUTTONS (Download PNG, Print QR, Copy Link, Kirim WhatsApp, Mode Proyektor, Generate QR Baru) */}
        <div className="flex flex-wrap items-center justify-center gap-3 pt-4 border-t border-gray-100 print:hidden">
          
          {/* Kirim WhatsApp */}
          <button
            onClick={() => {
              if (!currentEvent) return;
              const text = encodeURIComponent(
                `*DAFTAR HADIR ONLINE PGRI*\n` +
                `Kegiatan: *${currentEvent.namaKegiatan}*\n` +
                `Tanggal: ${currentEvent.tanggal} (${currentEvent.waktu})\n` +
                `Lokasi: ${currentEvent.lokasi}\n\n` +
                `Bapak/Ibu yang hadir, silakan mengisi daftar hadir melalui tautan barcode berikut:\n` +
                `${attendanceUrl}\n\n` +
                `_Persatuan Guru Republik Indonesia (PGRI)_`
              );
              window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
            }}
            className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-bold rounded-xl shadow-md transition-colors flex items-center gap-2"
          >
            <span>Kirim ke WhatsApp</span>
          </button>

          {/* Mode Proyektor Layar Penuh */}
          <button
            onClick={() => setFullscreenMode(true)}
            className="px-4 py-2.5 bg-gray-900 hover:bg-black text-white text-xs sm:text-sm font-bold rounded-xl shadow-md transition-colors flex items-center gap-2"
            title="Tampilkan barcode di layar penuh/proyektor aula"
          >
            <Maximize2 className="w-4 h-4 text-amber-300" />
            <span>Mode Proyektor</span>
          </button>

          {/* Download PNG */}
          <button
            onClick={handleDownloadPNG}
            className="px-4 py-2.5 bg-red-700 hover:bg-red-800 text-white text-xs sm:text-sm font-bold rounded-xl shadow-md transition-colors flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            <span>Download PNG</span>
          </button>

          {/* Print QR */}
          <button
            onClick={handlePrint}
            className="px-4 py-2.5 bg-gray-800 hover:bg-gray-900 text-white text-xs sm:text-sm font-bold rounded-xl shadow-md transition-colors flex items-center gap-2"
          >
            <Printer className="w-4 h-4" />
            <span>Print QR</span>
          </button>

          {/* Copy Link */}
          <button
            onClick={handleCopyLink}
            className="px-4 py-2.5 bg-white border border-gray-300 hover:border-red-600 text-gray-700 hover:text-red-700 text-xs sm:text-sm font-bold rounded-xl shadow-xs transition-colors flex items-center gap-2"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-emerald-600" />
                <span className="text-emerald-700">Tersalin!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>Copy Link</span>
              </>
            )}
          </button>

          {/* Generate QR Baru */}
          <button
            onClick={handleRegenerateQr}
            disabled={isRegenerating}
            className="px-4 py-2.5 bg-amber-50 border border-amber-300 text-amber-900 hover:bg-amber-100 text-xs sm:text-sm font-bold rounded-xl transition-colors flex items-center gap-2 disabled:opacity-50"
            title="Buat ulang token barcode untuk keamanan kegiatan"
          >
            <RefreshCw className={`w-4 h-4 ${isRegenerating ? 'animate-spin' : ''}`} />
            <span>Generate QR Baru</span>
          </button>
        </div>
      </div>
    </div>
  );
};

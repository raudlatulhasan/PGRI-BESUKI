import React, { useState } from 'react';
import { 
  Shield, 
  Wifi, 
  WifiOff, 
  Settings, 
  LogOut, 
  LogIn, 
  Menu, 
  X, 
  Calendar, 
  QrCode, 
  Users, 
  FileText, 
  LayoutDashboard 
} from 'lucide-react';
import { useFirebase } from '../firebase/context';
import { ActiveTab } from '../types';

interface Props {
  currentTab: ActiveTab | 'login' | 'attendance';
  onSelectTab: (tab: ActiveTab | 'login' | 'attendance') => void;
  onOpenConfig: () => void;
  isAdminLoggedIn: boolean;
}

export const Navbar: React.FC<Props> = ({ 
  currentTab, 
  onSelectTab, 
  onOpenConfig, 
  isAdminLoggedIn 
}) => {
  const { isConnected, signOut, isConfigured, demoMode } = useFirebase();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavClick = (tab: ActiveTab | 'login' | 'attendance') => {
    onSelectTab(tab);
    setMobileMenuOpen(false);
  };

  const handleLogout = async () => {
    if (window.confirm('Apakah Anda yakin ingin keluar dari akun Admin PGRI?')) {
      await signOut();
      onSelectTab('attendance');
      setMobileMenuOpen(false);
    }
  };

  return (
    <header className="bg-red-700 text-white shadow-md sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Brand Identity */}
          <div 
            onClick={() => handleNavClick(isAdminLoggedIn ? 'dashboard' : 'attendance')}
            className="flex items-center gap-3 cursor-pointer group select-none"
          >
            {/* PGRI Emblem Badge */}
            <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center shadow-md p-1 border-2 border-amber-400 group-hover:scale-105 transition-transform">
              <svg viewBox="0 0 100 100" className="w-full h-full" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="50" cy="50" r="46" fill="#B91C1C" stroke="#D97706" strokeWidth="4" />
                <path d="M50 20 L58 40 L80 40 L62 54 L68 76 L50 62 L32 76 L38 54 L20 40 L42 40 Z" fill="#F59E0B" opacity="0.4" />
                {/* Torch & Book */}
                <path d="M46 68 L54 68 L52 46 L48 46 Z" fill="#FFFFFF" />
                <path d="M44 45 C44 40, 50 30, 50 30 C50 30, 56 40, 56 45 C56 48, 53 50, 50 50 C47 50, 44 48, 44 45 Z" fill="#FBBF24" />
                <path d="M36 70 C42 66, 48 68, 50 72 C52 68, 58 66, 64 70 L64 75 C58 71, 52 73, 50 76 C48 73, 42 71, 36 75 Z" fill="#FFFFFF" />
              </svg>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-lg sm:text-xl tracking-tight text-white group-hover:text-red-100 transition-colors">
                  PGRI ATTENDANCE
                </span>
                {demoMode && (
                  <span className="px-1.5 py-0.5 bg-amber-500 text-slate-950 font-bold text-[10px] rounded uppercase tracking-wider">
                    Demo
                  </span>
                )}
              </div>
              <p className="text-[11px] sm:text-xs text-red-100 font-medium tracking-wide">
                Sistem Daftar Hadir Online PGRI
              </p>
            </div>
          </div>

          {/* Desktop Right Controls */}
          <div className="hidden md:flex items-center gap-3">
            {/* Connection Indicator */}
            <div 
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${
                isConnected 
                  ? 'bg-emerald-800/60 text-emerald-200 border border-emerald-500/40' 
                  : 'bg-rose-950 text-rose-200 border border-rose-600'
              }`}
              title={isConnected ? 'Koneksi Online' : 'Koneksi Terputus'}
            >
              {isConnected ? (
                <>
                  <Wifi className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Online</span>
                </>
              ) : (
                <>
                  <WifiOff className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
                  <span>Offline</span>
                </>
              )}
            </div>

            {/* Firebase Config Button */}
            <button
              onClick={onOpenConfig}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                isConfigured
                  ? 'bg-red-800 hover:bg-red-900 text-red-100 border border-red-600'
                  : 'bg-amber-500 hover:bg-amber-600 text-slate-900 font-bold animate-bounce'
              }`}
              title="Pengaturan Firebase"
            >
              <Settings className="w-3.5 h-3.5" />
              <span>Firebase</span>
            </button>

            {/* Admin navigation items if logged in */}
            {isAdminLoggedIn ? (
              <div className="flex items-center gap-2 pl-2 border-l border-red-600/70">
                <span className="px-2.5 py-1 bg-amber-500/20 border border-amber-400 text-amber-200 rounded-md text-xs font-bold flex items-center gap-1">
                  <Shield className="w-3 h-3 text-amber-300" />
                  Admin
                </span>
                <button
                  onClick={handleLogout}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-red-900/80 hover:bg-red-950 text-white rounded-lg text-xs font-semibold transition-colors"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Keluar</span>
                </button>
              </div>
            ) : (
              <button
                onClick={() => handleNavClick('login')}
                className="flex items-center gap-1.5 px-4 py-1.5 bg-white text-red-700 hover:bg-red-50 rounded-lg text-xs font-bold transition-all shadow-sm"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Login Admin</span>
              </button>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={onOpenConfig}
              className="p-1.5 text-white/90 hover:text-white rounded-md bg-red-800"
              title="Firebase Config"
            >
              <Settings className="w-4 h-4" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-red-800 text-white hover:bg-red-900 focus:outline-hidden"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-red-800 border-t border-red-600 px-4 pt-3 pb-5 space-y-3">
          <div className="flex items-center justify-between pb-3 border-b border-red-700 text-xs">
            <div className="flex items-center gap-1.5">
              {isConnected ? (
                <>
                  <Wifi className="w-3.5 h-3.5 text-emerald-300" />
                  <span className="text-emerald-200 font-medium">Koneksi Online</span>
                </>
              ) : (
                <>
                  <WifiOff className="w-3.5 h-3.5 text-rose-300" />
                  <span className="text-rose-200 font-medium">Koneksi Terputus</span>
                </>
              )}
            </div>
            <button
              onClick={() => { onOpenConfig(); setMobileMenuOpen(false); }}
              className="px-2 py-1 bg-red-900 text-red-200 text-xs rounded border border-red-600 flex items-center gap-1"
            >
              <Settings className="w-3 h-3" />
              <span>Config Firebase</span>
            </button>
          </div>

          {isAdminLoggedIn ? (
            <div className="space-y-1">
              <div className="text-[11px] uppercase tracking-wider text-red-300 font-bold px-2 py-1">
                Menu Admin PGRI
              </div>
              <button
                onClick={() => handleNavClick('dashboard')}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium ${
                  currentTab === 'dashboard' ? 'bg-red-900 text-white font-bold' : 'text-red-100 hover:bg-red-700'
                }`}
              >
                <LayoutDashboard className="w-4 h-4" />
                <span>Dashboard</span>
              </button>
              <button
                onClick={() => handleNavClick('events')}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium ${
                  currentTab === 'events' ? 'bg-red-900 text-white font-bold' : 'text-red-100 hover:bg-red-700'
                }`}
              >
                <Calendar className="w-4 h-4" />
                <span>Daftar Kegiatan</span>
              </button>
              <button
                onClick={() => handleNavClick('create-event')}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium ${
                  currentTab === 'create-event' ? 'bg-red-900 text-white font-bold' : 'text-red-100 hover:bg-red-700'
                }`}
              >
                <Calendar className="w-4 h-4" />
                <span>Buat Kegiatan</span>
              </button>
              <button
                onClick={() => handleNavClick('qrcode')}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium ${
                  currentTab === 'qrcode' ? 'bg-red-900 text-white font-bold' : 'text-red-100 hover:bg-red-700'
                }`}
              >
                <QrCode className="w-4 h-4" />
                <span>QR Code Absensi</span>
              </button>
              <button
                onClick={() => handleNavClick('attendance-list')}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium ${
                  currentTab === 'attendance-list' ? 'bg-red-900 text-white font-bold' : 'text-red-100 hover:bg-red-700'
                }`}
              >
                <Users className="w-4 h-4" />
                <span>Daftar Peserta Hadir</span>
              </button>
              <button
                onClick={() => handleNavClick('reports')}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium ${
                  currentTab === 'reports' ? 'bg-red-900 text-white font-bold' : 'text-red-100 hover:bg-red-700'
                }`}
              >
                <FileText className="w-4 h-4" />
                <span>Laporan & PDF</span>
              </button>
              <div className="pt-2 border-t border-red-700">
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center gap-2.5 px-3 py-2 text-rose-200 hover:bg-red-900 rounded-lg text-sm font-semibold"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Logout Admin</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-2 pt-2">
              <button
                onClick={() => handleNavClick('attendance')}
                className="w-full py-2.5 px-3 text-center bg-red-700 text-white rounded-lg text-sm font-semibold"
              >
                Formulir Absensi Peserta
              </button>
              <button
                onClick={() => handleNavClick('login')}
                className="w-full py-2.5 px-3 text-center bg-white text-red-700 hover:bg-red-50 rounded-lg text-sm font-bold shadow-xs flex items-center justify-center gap-2"
              >
                <LogIn className="w-4 h-4" />
                <span>Login Admin PGRI</span>
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
};

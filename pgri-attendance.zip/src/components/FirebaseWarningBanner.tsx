import React from 'react';
import { AlertCircle, Settings, Play } from 'lucide-react';
import { useFirebase } from '../firebase/context';

interface Props {
  onOpenConfig: () => void;
}

export const FirebaseWarningBanner: React.FC<Props> = ({ onOpenConfig }) => {
  const { isConfigured, demoMode, setDemoMode } = useFirebase();

  if (isConfigured) return null;

  return (
    <div className="bg-amber-500 text-slate-900 border-b border-amber-600 shadow-md">
      <div className="max-w-7xl mx-auto px-4 py-2.5 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs sm:text-sm">
        <div className="flex items-center gap-2.5 font-medium">
          <AlertCircle className="w-5 h-5 shrink-0 text-slate-950 animate-pulse" />
          <span>
            <strong>Perhatian:</strong> Firebase belum dikonfigurasi. Silakan masukkan konfigurasi Firebase pada file konfigurasi aplikasi.
          </span>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onOpenConfig}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 text-white rounded-lg font-semibold hover:bg-slate-800 transition-colors shadow-xs"
          >
            <Settings className="w-3.5 h-3.5" />
            Konfigurasi Firebase
          </button>

          {!demoMode ? (
            <button
              onClick={() => setDemoMode(true)}
              className="flex items-center gap-1 px-2.5 py-1.5 bg-amber-200 text-amber-950 rounded-lg hover:bg-amber-100 transition-colors font-medium border border-amber-400"
              title="Aktifkan contoh data sementara untuk menguji fitur tanpa koneksi cloud"
            >
              <Play className="w-3 h-3" />
              Coba Demo Data
            </button>
          ) : (
            <span className="px-2 py-1 bg-amber-700 text-white rounded font-bold text-xs uppercase tracking-wider">
              DEMO DATA AKTIF
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect, useMemo } from 'react';
import { 
  Users, 
  Search, 
  Filter, 
  ArrowUpDown, 
  Edit3, 
  Trash2, 
  Calendar, 
  Download, 
  FileText, 
  Radio, 
  X,
  School,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';
import { PGRIEvent, AttendanceRecord } from '../types';
import { getEvents } from '../services/eventService';
import { 
  subscribeToEventAttendance, 
  deleteAttendanceRecord 
} from '../services/attendanceService';
import { EditAttendanceModal } from './EditAttendanceModal';

interface Props {
  initialEventId?: string;
  onNavigateToReport: (eventId: string) => void;
}

type SortField = 'nomor' | 'nama' | 'asalSekolah' | 'waktuHadir';
type SortOrder = 'asc' | 'desc';

export const AttendanceListView: React.FC<Props> = ({ 
  initialEventId, 
  onNavigateToReport 
}) => {
  const [events, setEvents] = useState<PGRIEvent[]>([]);
  const [selectedEventId, setSelectedEventId] = useState<string>(initialEventId || '');
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterTanggal, setFilterTanggal] = useState<string>('');
  const [filterSekolah, setFilterSekolah] = useState<string>('');
  const [filterJabatan, setFilterJabatan] = useState<string>('');

  // Sorting
  const [sortField, setSortField] = useState<SortField>('waktuHadir');
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');

  // Edit Modal State
  const [editingRecord, setEditingRecord] = useState<AttendanceRecord | null>(null);

  // Load events
  useEffect(() => {
    getEvents().then(all => {
      setEvents(all);
      if (!selectedEventId && all.length > 0) {
        setSelectedEventId(all[0].id);
      }
    });
  }, [selectedEventId]);

  // Subscribe to realtime attendance for selected event
  useEffect(() => {
    if (!selectedEventId) return;

    setLoading(true);
    const unsubscribe = subscribeToEventAttendance(selectedEventId, (data) => {
      setRecords(data);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [selectedEventId]);

  const activeEvent = useMemo(() => {
    return events.find(e => e.id === selectedEventId) || null;
  }, [events, selectedEventId]);

  // Distinct values for filter dropdowns
  const uniqueDates = useMemo(() => {
    return Array.from(new Set(records.map(r => r.tanggalHadir))).filter(Boolean);
  }, [records]);

  const uniqueSchools = useMemo(() => {
    return Array.from(new Set(records.map(r => r.asalSekolah))).filter(Boolean);
  }, [records]);

  const uniquePositions = useMemo(() => {
    return Array.from(new Set(records.map(r => r.jabatanPGRI))).filter(Boolean);
  }, [records]);

  // Filtered & Sorted Records
  const processedRecords = useMemo(() => {
    let result = [...records];

    // Search (Nomor, Nama, Sekolah, Jabatan)
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(r => 
        r.nomor.toLowerCase().includes(q) ||
        r.nama.toLowerCase().includes(q) ||
        r.asalSekolah.toLowerCase().includes(q) ||
        r.jabatanPGRI.toLowerCase().includes(q)
      );
    }

    // Filters
    if (filterTanggal) {
      result = result.filter(r => r.tanggalHadir === filterTanggal);
    }
    if (filterSekolah) {
      result = result.filter(r => r.asalSekolah === filterSekolah);
    }
    if (filterJabatan) {
      result = result.filter(r => r.jabatanPGRI === filterJabatan);
    }

    // Sorting
    result.sort((a, b) => {
      let valA: string | number = a[sortField];
      let valB: string | number = b[sortField];

      if (sortField === 'nomor') {
        const numA = parseInt(a.nomor, 10) || 0;
        const numB = parseInt(b.nomor, 10) || 0;
        return sortOrder === 'asc' ? numA - numB : numB - numA;
      }

      valA = String(valA).toLowerCase();
      valB = String(valB).toLowerCase();

      if (valA < valB) return sortOrder === 'asc' ? -1 : 1;
      if (valA > valB) return sortOrder === 'asc' ? 1 : -1;
      return 0;
    });

    return result;
  }, [records, searchQuery, filterTanggal, filterSekolah, filterJabatan, sortField, sortOrder]);

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  const handleDelete = async (record: AttendanceRecord) => {
    if (window.confirm(`Hapus catatan kehadiran untuk ${record.nama} (Nomor: ${record.nomor})?`)) {
      try {
        await deleteAttendanceRecord(record.eventId, record.id);
      } catch (err) {
        console.error("Gagal menghapus:", err);
        alert("Gagal menghapus catatan.");
      }
    }
  };

  const handleClearFilters = () => {
    setSearchQuery('');
    setFilterTanggal('');
    setFilterSekolah('');
    setFilterJabatan('');
  };

  const hasActiveFilters = Boolean(searchQuery || filterTanggal || filterSekolah || filterJabatan);

  return (
    <div className="space-y-6">
      
      {/* Top Controls: Event Selector & Live Status */}
      <div className="bg-white p-5 rounded-2xl shadow-xs border border-gray-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex-1">
          <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
            Kegiatan PGRI Aktif:
          </label>
          <select
            value={selectedEventId}
            onChange={(e) => setSelectedEventId(e.target.value)}
            className="w-full sm:max-w-md text-sm font-bold text-gray-800 bg-gray-50 border-2 border-gray-200 rounded-xl px-3.5 py-2.5 focus:border-red-600 focus:outline-hidden"
          >
            {events.map((ev) => (
              <option key={ev.id} value={ev.id}>
                {ev.namaKegiatan} — {ev.tanggal} ({ev.status})
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          {/* Realtime Badge */}
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-50 text-emerald-700 text-xs font-bold border border-emerald-200">
            <Radio className="w-3.5 h-3.5 animate-pulse text-emerald-600" />
            <span>Realtime Listener Aktif</span>
          </div>

          {/* Quick PDF Report Link */}
          {selectedEventId && (
            <button
              onClick={() => onNavigateToReport(selectedEventId)}
              className="px-4 py-2 bg-red-700 hover:bg-red-800 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Cetak Laporan</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Table Card */}
      <div className="bg-white rounded-2xl shadow-xs border border-gray-200 overflow-hidden">
        
        {/* Search & Filter Header Bar */}
        <div className="p-5 border-b border-gray-100 space-y-4">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-red-700" />
              <h2 className="text-base font-extrabold text-gray-900">
                Daftar Peserta Hadir
              </h2>
              <span className="px-2.5 py-0.5 bg-red-100 text-red-800 font-extrabold text-xs rounded-full">
                {processedRecords.length} / {records.length} Peserta
              </span>
            </div>

            {hasActiveFilters && (
              <button
                onClick={handleClearFilters}
                className="text-xs text-red-700 hover:text-red-900 font-bold flex items-center gap-1 self-start sm:self-auto"
              >
                <X className="w-3.5 h-3.5" />
                <span>Reset Semua Filter</span>
              </button>
            )}
          </div>

          {/* Search Box */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div className="sm:col-span-4 relative">
              <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari berdasarkan Nomor, Nama Peserta, Asal Sekolah, atau Jabatan..."
                className="w-full pl-10 pr-4 py-2 text-sm bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:border-red-600 focus:outline-hidden transition-colors"
              />
            </div>

            {/* Filter Tanggal */}
            <div>
              <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">
                Filter Tanggal
              </label>
              <select
                value={filterTanggal}
                onChange={(e) => setFilterTanggal(e.target.value)}
                className="w-full text-xs bg-gray-50 border border-gray-200 rounded-lg p-2 focus:outline-hidden font-medium"
              >
                <option value="">Semua Tanggal</option>
                {uniqueDates.map(d => (
                  <option key={d} value={d}>{d}</option>
                ))}
              </select>
            </div>

            {/* Filter Sekolah */}
            <div>
              <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">
                Filter Sekolah
              </label>
              <select
                value={filterSekolah}
                onChange={(e) => setFilterSekolah(e.target.value)}
                className="w-full text-xs bg-gray-50 border border-gray-200 rounded-lg p-2 focus:outline-hidden font-medium"
              >
                <option value="">Semua Asal Sekolah</option>
                {uniqueSchools.map(s => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>

            {/* Filter Jabatan */}
            <div>
              <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">
                Filter Jabatan
              </label>
              <select
                value={filterJabatan}
                onChange={(e) => setFilterJabatan(e.target.value)}
                className="w-full text-xs bg-gray-50 border border-gray-200 rounded-lg p-2 focus:outline-hidden font-medium"
              >
                <option value="">Semua Jabatan</option>
                {uniquePositions.map(j => (
                  <option key={j} value={j}>{j}</option>
                ))}
              </select>
            </div>

            {/* Sort Dropdown */}
            <div>
              <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">
                Urutkan Berdasarkan
              </label>
              <div className="flex gap-1">
                <select
                  value={sortField}
                  onChange={(e) => setSortField(e.target.value as SortField)}
                  className="w-full text-xs bg-gray-50 border border-gray-200 rounded-lg p-2 focus:outline-hidden font-medium"
                >
                  <option value="waktuHadir">Waktu Hadir</option>
                  <option value="nomor">Nomor Peserta</option>
                  <option value="nama">Nama Lengkap</option>
                  <option value="asalSekolah">Asal Sekolah</option>
                </select>
                <button
                  onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
                  className="p-2 border border-gray-200 bg-gray-50 hover:bg-gray-100 rounded-lg text-gray-600 text-xs font-bold"
                  title={sortOrder === 'asc' ? 'Urutan Naik (A-Z / 1-9)' : 'Urutan Turun (Z-A / 9-1)'}
                >
                  {sortOrder === 'asc' ? '▲' : '▼'}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Table Content */}
        {loading ? (
          <div className="p-12 text-center text-gray-500">
            <div className="w-8 h-8 border-4 border-red-700 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
            <p className="text-xs font-semibold">Memuat data peserta realtime...</p>
          </div>
        ) : processedRecords.length === 0 ? (
          <div className="p-12 text-center text-gray-400">
            <Users className="w-12 h-12 mx-auto text-gray-300 mb-2" />
            <h3 className="text-sm font-bold text-gray-700">Tidak ada data kehadiran yang cocok</h3>
            <p className="text-xs text-gray-400 mt-1">
              {records.length === 0 
                ? 'Belum ada peserta yang mengisi daftar hadir untuk kegiatan ini.' 
                : 'Coba ubah kata kunci pencarian atau reset filter yang dipilih.'}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="bg-gray-50 border-b border-gray-200 text-gray-600 text-[11px] uppercase tracking-wider font-bold">
                <tr>
                  <th className="py-3.5 px-4 text-center w-12">No</th>
                  <th 
                    onClick={() => toggleSort('nomor')}
                    className="py-3.5 px-4 cursor-pointer hover:bg-gray-100 transition-colors w-24"
                  >
                    <div className="flex items-center gap-1">
                      <span>Nomor</span>
                      <ArrowUpDown className="w-3 h-3 text-gray-400" />
                    </div>
                  </th>
                  <th 
                    onClick={() => toggleSort('nama')}
                    className="py-3.5 px-4 cursor-pointer hover:bg-gray-100 transition-colors"
                  >
                    <div className="flex items-center gap-1">
                      <span>Nama Lengkap</span>
                      <ArrowUpDown className="w-3 h-3 text-gray-400" />
                    </div>
                  </th>
                  <th 
                    onClick={() => toggleSort('asalSekolah')}
                    className="py-3.5 px-4 cursor-pointer hover:bg-gray-100 transition-colors"
                  >
                    <div className="flex items-center gap-1">
                      <span>Asal Sekolah / Unit</span>
                      <ArrowUpDown className="w-3 h-3 text-gray-400" />
                    </div>
                  </th>
                  <th className="py-3.5 px-4">Jabatan</th>
                  <th 
                    onClick={() => toggleSort('waktuHadir')}
                    className="py-3.5 px-4 cursor-pointer hover:bg-gray-100 transition-colors text-center w-28"
                  >
                    <div className="flex items-center justify-center gap-1">
                      <span>Waktu Hadir</span>
                      <ArrowUpDown className="w-3 h-3 text-gray-400" />
                    </div>
                  </th>
                  <th className="py-3.5 px-4 text-center w-24">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 text-gray-800">
                {processedRecords.map((record, index) => (
                  <tr key={record.id} className="hover:bg-red-50/40 transition-colors">
                    <td className="py-3 px-4 text-center font-mono text-gray-400 text-xs">
                      {index + 1}
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-red-700">
                      {record.nomor}
                    </td>
                    <td className="py-3 px-4 font-bold text-gray-900">
                      {record.nama}
                    </td>
                    <td className="py-3 px-4 text-gray-600">
                      {record.asalSekolah}
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2.5 py-1 rounded-md text-xs font-semibold bg-gray-100 text-gray-700">
                        {record.jabatanPGRI}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center font-mono text-xs font-semibold text-emerald-700">
                      {record.waktuHadir}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => setEditingRecord(record)}
                          className="p-1.5 text-gray-500 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-colors"
                          title="Perbaiki / Edit Data"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(record)}
                          className="p-1.5 text-gray-500 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors"
                          title="Hapus Peserta"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Edit Modal */}
      {editingRecord && (
        <EditAttendanceModal
          isOpen={Boolean(editingRecord)}
          record={editingRecord}
          onClose={() => setEditingRecord(null)}
          onUpdated={() => {
            // Updated in firestore, onSnapshot handles update
          }}
        />
      )}
    </div>
  );
};

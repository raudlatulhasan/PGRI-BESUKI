import React, { useState } from 'react';
import { X, Save, RefreshCw, Database, Key, HelpCircle, CheckCircle2, AlertTriangle } from 'lucide-react';
import { useFirebase } from '../firebase/context';
import { FirebaseConfig } from '../types';
import { isFirebaseConfigured } from '../firebase/config';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const FirebaseConfigModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const { config, saveConfig, resetConfig, demoMode, setDemoMode } = useFirebase();

  const [formData, setFormData] = useState<FirebaseConfig>({ ...config });
  const [jsonInput, setJsonInput] = useState<string>('');
  const [inputMode, setInputMode] = useState<'form' | 'json'>('form');
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');

  if (!isOpen) return null;

  const handleInputChange = (field: keyof FirebaseConfig, val: string) => {
    setFormData(prev => ({ ...prev, [field]: val }));
  };

  const handleJsonPaste = () => {
    try {
      setErrorMsg('');
      // Clean up common JS format if user pasted `const firebaseConfig = { ... };`
      let cleaned = jsonInput.trim();
      if (cleaned.startsWith('const') || cleaned.startsWith('let') || cleaned.startsWith('var')) {
        const eqIdx = cleaned.indexOf('=');
        if (eqIdx !== -1) {
          cleaned = cleaned.substring(eqIdx + 1).trim();
        }
      }
      if (cleaned.endsWith(';')) {
        cleaned = cleaned.slice(0, -1).trim();
      }
      // If keys are unquoted, quote them
      cleaned = cleaned.replace(/([{,]\s*)([a-zA-Z0-9_]+)\s*:/g, '$1"$2":');
      // replace single quotes with double quotes
      cleaned = cleaned.replace(/'/g, '"');

      const parsed = JSON.parse(cleaned);
      setFormData(prev => ({
        ...prev,
        apiKey: parsed.apiKey || '',
        authDomain: parsed.authDomain || '',
        projectId: parsed.projectId || '',
        storageBucket: parsed.storageBucket || '',
        messagingSenderId: parsed.messagingSenderId || '',
        appId: parsed.appId || ''
      }));
      setInputMode('form');
    } catch {
      setErrorMsg('Format JSON tidak valid. Pastikan format objek Firebase benar.');
    }
  };

  const handleSave = () => {
    if (!formData.apiKey || formData.apiKey.includes('YOUR_API_KEY')) {
      setErrorMsg('Silakan masukkan API Key Firebase yang valid.');
      return;
    }
    if (!formData.projectId || formData.projectId.includes('YOUR_PROJECT_ID')) {
      setErrorMsg('Silakan masukkan Project ID Firebase yang valid.');
      return;
    }

    saveConfig(formData);
    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
      onClose();
    }, 1200);
  };

  const handleReset = () => {
    if (window.confirm('Reset konfigurasi ke default placeholder?')) {
      resetConfig();
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-red-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-lg">
              <Database className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Konfigurasi Google Firebase</h2>
              <p className="text-xs text-red-100">Koneksi Database Firestore & Autentikasi PGRI Attendance</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-white/20 transition-colors text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-gray-700">
          {/* Status pill */}
          <div className="flex items-center justify-between p-3.5 rounded-xl bg-gray-50 border border-gray-200">
            <div className="flex items-center gap-3">
              {isFirebaseConfigured(formData) ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              ) : (
                <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0" />
              )}
              <div>
                <p className="text-sm font-semibold text-gray-800">
                  {isFirebaseConfigured(formData) ? 'Status: Terhubung ke Firebase' : 'Status: Menggunakan Placeholder'}
                </p>
                <p className="text-xs text-gray-500">
                  {isFirebaseConfigured(formData) 
                    ? `Project ID: ${formData.projectId}` 
                    : 'Data akan tersimpan permanen di cloud setelah memasukkan konfigurasi Firebase.'}
                </p>
              </div>
            </div>

            <button
              onClick={() => setDemoMode(!demoMode)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors ${
                demoMode 
                  ? 'bg-amber-100 text-amber-800 border-amber-300' 
                  : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-100'
              }`}
            >
              {demoMode ? 'Mode Demo Aktif' : 'Coba Mode Demo'}
            </button>
          </div>

          {/* Mode Switcher */}
          <div className="flex border-b border-gray-200">
            <button
              type="button"
              onClick={() => setInputMode('form')}
              className={`pb-2.5 px-4 text-sm font-medium border-b-2 transition-colors ${
                inputMode === 'form' 
                  ? 'border-red-700 text-red-700 font-bold' 
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Isi Form
            </button>
            <button
              type="button"
              onClick={() => setInputMode('json')}
              className={`pb-2.5 px-4 text-sm font-medium border-b-2 transition-colors ${
                inputMode === 'json' 
                  ? 'border-red-700 text-red-700 font-bold' 
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Paste JSON dari Firebase Console
            </button>
          </div>

          {errorMsg && (
            <div className="p-3 text-xs bg-red-50 text-red-700 border border-red-200 rounded-lg flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {saveSuccess && (
            <div className="p-3 text-xs bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-lg flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>Konfigurasi berhasil disimpan! Memuat ulang sistem...</span>
            </div>
          )}

          {inputMode === 'json' ? (
            <div className="space-y-3">
              <label className="block text-xs font-semibold text-gray-600">
                Tempel (Paste) blok kode `const firebaseConfig = &#123; ... &#125;;` langsung dari Firebase Console:
              </label>
              <textarea
                value={jsonInput}
                onChange={(e) => setJsonInput(e.target.value)}
                placeholder={`const firebaseConfig = {\n  apiKey: "AIzaSy...",\n  authDomain: "pgri-attend.firebaseapp.com",\n  projectId: "pgri-attend",\n  storageBucket: "pgri-attend.appspot.com",\n  messagingSenderId: "1234567890",\n  appId: "1:1234567890:web:abcdef"\n};`}
                rows={7}
                className="w-full font-mono text-xs p-3 bg-gray-50 border border-gray-300 rounded-xl focus:ring-2 focus:ring-red-600 focus:outline-hidden"
              />
              <button
                type="button"
                onClick={handleJsonPaste}
                className="px-4 py-2 bg-gray-800 hover:bg-gray-900 text-white text-xs font-medium rounded-lg transition-colors"
              >
                Terapkan ke Form
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">
                  API Key <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <Key className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    value={formData.apiKey}
                    onChange={(e) => handleInputChange('apiKey', e.target.value)}
                    placeholder="AIzaSy..."
                    className="w-full pl-9 pr-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-600 focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">
                  Project ID <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.projectId}
                  onChange={(e) => handleInputChange('projectId', e.target.value)}
                  placeholder="pgri-attendance-123"
                  className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-600 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">
                  Auth Domain
                </label>
                <input
                  type="text"
                  value={formData.authDomain}
                  onChange={(e) => handleInputChange('authDomain', e.target.value)}
                  placeholder="pgri-attendance.firebaseapp.com"
                  className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-600 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">
                  Storage Bucket
                </label>
                <input
                  type="text"
                  value={formData.storageBucket}
                  onChange={(e) => handleInputChange('storageBucket', e.target.value)}
                  placeholder="pgri-attendance.appspot.com"
                  className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-600 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">
                  Messaging Sender ID
                </label>
                <input
                  type="text"
                  value={formData.messagingSenderId}
                  onChange={(e) => handleInputChange('messagingSenderId', e.target.value)}
                  placeholder="1234567890"
                  className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-600 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">
                  App ID
                </label>
                <input
                  type="text"
                  value={formData.appId}
                  onChange={(e) => handleInputChange('appId', e.target.value)}
                  placeholder="1:1234567890:web:abcdef..."
                  className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-600 focus:outline-hidden"
                />
              </div>
            </div>
          )}

          <div className="p-3.5 bg-blue-50 border border-blue-200 rounded-xl text-xs text-blue-900 flex items-start gap-2.5">
            <HelpCircle className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold mb-0.5">Panduan Lengkap Setup:</p>
              <p className="text-blue-800 leading-relaxed">
                Jika belum membuat project di Google Firebase, silakan baca file <code className="bg-blue-100 px-1 py-0.5 rounded font-mono">FIREBASE_SETUP.md</code> untuk petunjuk langkah demi langkah mengaktifkan Firestore Database & Authentication.
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex items-center justify-between">
          <button
            type="button"
            onClick={handleReset}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-gray-600 hover:text-red-700 transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
            Reset Default
          </button>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-100 transition-colors"
            >
              Tutup
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="flex items-center gap-2 px-5 py-2 text-sm font-bold text-white bg-red-700 hover:bg-red-800 rounded-lg shadow-sm transition-colors"
            >
              <Save className="w-4 h-4" />
              Simpan Konfigurasi
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

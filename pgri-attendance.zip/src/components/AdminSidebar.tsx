import React from 'react';
import { 
  LayoutDashboard, 
  Calendar, 
  PlusCircle, 
  QrCode, 
  Users, 
  FileText, 
  Settings, 
  LogOut,
  ChevronRight,
  Shield
} from 'lucide-react';
import { ActiveTab } from '../types';
import { useFirebase } from '../firebase/context';

interface Props {
  currentTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  onOpenConfig: () => void;
  onLogout: () => void;
}

export const AdminSidebar: React.FC<Props> = ({ 
  currentTab, 
  onSelectTab, 
  onOpenConfig, 
  onLogout 
}) => {
  const { user, previewAdmin } = useFirebase();

  const menuItems: { id: ActiveTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'events', label: 'Kegiatan', icon: Calendar },
    { id: 'create-event', label: 'Buat Kegiatan', icon: PlusCircle },
    { id: 'qrcode', label: 'QR Code', icon: QrCode },
    { id: 'attendance-list', label: 'Daftar Hadir', icon: Users },
    { id: 'reports', label: 'Laporan & PDF', icon: FileText },
    { id: 'settings', label: 'Pengaturan', icon: Settings },
  ];

  return (
    <aside className="w-64 bg-white border-r border-gray-200 flex flex-col shrink-0 min-h-[calc(100vh-4rem)]">
      
      {/* Admin Profile Card */}
      <div className="p-4 border-b border-gray-100 bg-gray-50/70">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-red-700 text-white flex items-center justify-center font-bold text-sm shadow-xs">
            <Shield className="w-5 h-5 text-amber-300" />
          </div>
          <div className="overflow-hidden">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-gray-900 truncate">Admin PGRI</span>
              <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
            </div>
            <p className="text-[11px] text-gray-400 truncate">
              {user?.email || previewAdmin?.email || 'raudlatulhasan04@gmail.com'}
            </p>
          </div>
        </div>
      </div>

      {/* Navigation Links */}
      <nav className="p-3 space-y-1 flex-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                if (item.id === 'settings') {
                  onOpenConfig();
                } else {
                  onSelectTab(item.id);
                }
              }}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                isActive
                  ? 'bg-red-700 text-white shadow-sm'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-gray-400'}`} />
                <span>{item.label}</span>
              </div>
              {isActive && <ChevronRight className="w-4 h-4 opacity-75" />}
            </button>
          );
        })}
      </nav>

      {/* Bottom Logout Button */}
      <div className="p-3 border-t border-gray-100">
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-3.5 py-2.5 text-xs sm:text-sm font-semibold text-rose-700 hover:bg-rose-50 rounded-xl transition-colors"
        >
          <LogOut className="w-4 h-4" />
          <span>Logout Admin</span>
        </button>
      </div>
    </aside>
  );
};

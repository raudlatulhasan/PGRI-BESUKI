import React, { useState, useEffect } from 'react';
import { 
  Calendar, 
  Clock, 
  MapPin, 
  Building2, 
  CheckCircle2, 
  AlertCircle, 
  UserCheck, 
  ArrowRight, 
  School, 
  Briefcase, 
  User, 
  WifiOff,
  QrCode
} from 'lucide-react';
import { PGRIEvent, AttendanceRecord } from '../types';
import { getEventById, getEventByToken, getActiveEvents, getEvents, INITIAL_DEMO_EVENTS } from '../services/eventService';
import { submitAttendance } from '../services/attendanceService';
import { useFirebase } from '../firebase/context';

interface Props {
  initialEventId?: string | null;
  initialToken?: string | null;
  onNavigateToLogin: () => void;
}

export const ParticipantAttendanceView: React.FC<Props> = ({ 
  initialEventId, 
  initialToken, 
  onNavigateToLogin 
}) => {
  const { isConnected } = useFirebase();

  const [loadingEvent, setLoadingEvent] = useState<boolean>(true);
  const [event, setEvent] = useState<PGRIEvent | null>(null);
  const [eventNotFound, setEventNotFound] = useState<boolean>(false);

  // Form states: Nomor diisi otomatis oleh sistem, peserta mengisi Nama, Asal Sekolah, dan Jabatan (manual)
  const [nama, setNama] = useState<string>('');
  const [asalSekolah, setAsalSekolah] = useState<string>('');
  const [jabatan, setJabatan] = useState<string>('');

  // Status states
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [successRecord, setSuccessRecord] = useState<AttendanceRecord | null>(null);

  // Load target event from barcode link (token or eventId)
  useEffect(() => {
    let isMounted = true;
    const loadEvent = async () => {
      setLoadingEvent(true);
      setEventNotFound(false);
      setErrorMessage('');

      try {
        let matched: PGRIEvent | null = null;

        // Prioritize direct event ID if provided in URL barcode link
        if (initialEventId) {
          matched = await getEventById(initialEventId);
        } else if (initialToken) {
          matched = await getEventByToken(initialToken);
        }

        if (!matched) {
          // If no specific event specified in URL, fetch current active event
          const activeList = await getActiveEvents();
          if (isMounted) {
            if (activeList.length > 0) {
              setEvent(activeList[0]);
            } else {
              const all = await getEvents();
              if (all.length > 0) {
                setEvent(all[0]);
              } else {
                setEvent(INITIAL_DEMO_EVENTS[0]);
              }
            }
          }
        } else {
          if (isMounted) {
            setEvent(matched);
          }
        }
      } catch (err) {
        console.error("Error loading event from barcode link:", err);
        if (isMounted) {
          // If URL had a specific invalid token, flag as not found; otherwise show default event
          if (initialEventId || initialToken) {
            setEventNotFound(true);
          } else {
            setEvent(INITIAL_DEMO_EVENTS[0]);
          }
        }
      } finally {
        if (isMounted) setLoadingEvent(false);
      }
    };

    loadEvent();
    return () => { isMounted = false; };
  }, [initialEventId, initialToken]);

  // Handle Submit Attendance
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!isConnected) {
      setErrorMessage('Koneksi internet bermasalah. Silakan periksa koneksi Anda dan coba lagi.');
      return;
    }

    if (!event) {
      setErrorMessage('Kegiatan tidak ditemukan.');
      return;
    }

    if (event.status !== 'Aktif') {
      setErrorMessage('Pendaftaran kehadiran untuk kegiatan ini telah ditutup.');
      return;
    }

    // Nama validation: min 3 chars
    const cleanNama = nama.trim();
    if (!cleanNama) {
      setErrorMessage('Nama lengkap wajib diisi.');
      return;
    }
    if (cleanNama.length < 3) {
      setErrorMessage('Nama lengkap minimal 3 karakter.');
      return;
    }

    // Asal Sekolah validation: required
    const cleanSekolah = asalSekolah.trim();
    if (!cleanSekolah) {
      setErrorMessage('Asal sekolah wajib diisi.');
      return;
    }

    // Jabatan validation: manual entry required
    const cleanJabatan = jabatan.trim();
    if (!cleanJabatan) {
      setErrorMessage('Jabatan wajib diisi.');
      return;
    }

    // Start submit (Double-submit prevention)
    setIsSubmitting(true);

    try {
      const res = await submitAttendance({
        nama: cleanNama,
        asalSekolah: cleanSekolah,
        jabatanPGRI: cleanJabatan,
        eventId: event.id
      });

      if (!res.success) {
        setErrorMessage(res.error || 'Data belum berhasil disimpan. Silakan coba lagi.');
      } else if (res.record) {
        setSuccessRecord(res.record);
      }
    } catch (err) {
      console.error("Attendance submission exception:", err);
      setErrorMessage('✕ Data belum berhasil disimpan. Silakan coba lagi.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetForm = () => {
    setSuccessRecord(null);
    setNama('');
    setAsalSekolah('');
    setJabatan('');
    setErrorMessage('');
  };

  // Loading Screen
  if (loadingEvent) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center p-6 text-center">
        <div className="w-12 h-12 border-4 border-red-700 border-t-transparent rounded-full animate-spin mb-4" />
        <p className="text-gray-700 font-semibold text-base">Membuka Lembar Hadir Kegiatan PGRI...</p>
        <p className="text-gray-400 text-xs mt-1">Memeriksa tautan barcode & status kegiatan</p>
      </div>
    );
  }

  // Invalid QR Code or Not Found Screen
  if (eventNotFound || !event) {
    return (
      <div className="max-w-lg mx-auto my-8 px-4">
        <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden text-center p-8">
          <div className="w-16 h-16 bg-red-100 text-red-700 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertCircle className="w-9 h-9" />
          </div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">QR CODE TIDAK VALID</h2>
          <p className="text-gray-600 text-sm mb-6 leading-relaxed">
            Kode kehadiran ini tidak ditemukan atau kegiatan sudah ditutup oleh panitia PGRI.
          </p>
          <div className="p-4 bg-gray-50 rounded-xl text-xs text-gray-500 mb-6 text-left space-y-1.5">
            <p><strong>Petunjuk untuk peserta:</strong></p>
            <p>• Pastikan Anda memindai barcode/QR Code resmi yang ditampilkan admin/panitia di lokasi acara.</p>
            <p>• Jika barcode tidak terbaca, mintalah link daftar hadir langsung kepada panitia.</p>
          </div>
          <button
            onClick={onNavigateToLogin}
            className="w-full py-3 bg-red-700 hover:bg-red-800 text-white rounded-xl font-bold text-sm shadow-md transition-colors"
          >
            Masuk Sebagai Panitia / Admin PGRI
          </button>
        </div>
      </div>
    );
  }

  // SUCCESS SCREEN
  if (successRecord) {
    return (
      <div className="max-w-lg mx-auto my-8 px-4 animate-in fade-in zoom-in-95 duration-200">
        <div className="bg-white rounded-2xl shadow-2xl border border-emerald-100 overflow-hidden text-center">
          {/* Header Banner */}
          <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white p-6 sm:p-8">
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3 backdrop-blur-xs">
              <CheckCircle2 className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight">KEHADIRAN BERHASIL</h2>
            <p className="text-emerald-100 text-xs sm:text-sm mt-1">
              Alhamdulillah, data kehadiran Anda berhasil dicatat.
            </p>
          </div>

          {/* Details Card */}
          <div className="p-6 text-left space-y-4">
            <div className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-100 text-center">
              <p className="text-xs text-emerald-800 font-semibold uppercase tracking-wider">Kegiatan</p>
              <p className="text-base font-bold text-gray-900 mt-0.5">{event.namaKegiatan}</p>
            </div>

            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="bg-gray-50 p-3 rounded-xl border border-gray-100">
                <span className="text-[11px] font-semibold text-gray-400 block uppercase">Nomor Hadir</span>
                <span className="font-bold text-gray-800 text-base">{successRecord.nomor}</span>
              </div>
              <div className="bg-gray-50 p-3 rounded-xl border border-gray-100">
                <span className="text-[11px] font-semibold text-gray-400 block uppercase">Waktu Hadir</span>
                <span className="font-bold text-emerald-700 text-base">{successRecord.waktuHadir}</span>
              </div>
            </div>

            <div className="bg-gray-50 p-3.5 rounded-xl border border-gray-100 space-y-2 text-sm">
              <div>
                <span className="text-[11px] font-semibold text-gray-400 block uppercase">Nama Lengkap</span>
                <span className="font-semibold text-gray-900">{successRecord.nama}</span>
              </div>
              <div className="pt-2 border-t border-gray-200">
                <span className="text-[11px] font-semibold text-gray-400 block uppercase">Asal Sekolah</span>
                <span className="text-gray-800">{successRecord.asalSekolah}</span>
              </div>
              <div className="pt-2 border-t border-gray-200">
                <span className="text-[11px] font-semibold text-gray-400 block uppercase">Jabatan</span>
                <span className="text-gray-800 font-medium">{successRecord.jabatanPGRI}</span>
              </div>
            </div>

            <div className="pt-3">
              <button
                type="button"
                onClick={handleResetForm}
                className="w-full py-3.5 bg-red-700 hover:bg-red-800 text-white rounded-xl font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2"
              >
                <span>SELESAI</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ACTIVE / INACTIVE ATTENDANCE FORM SCREEN
  return (
    <div className="max-w-xl mx-auto my-6 px-4 pb-12">
      {/* Main Form Card */}
      <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
        
        {/* Event Header Banner */}
        <div className="bg-gradient-to-r from-red-700 via-red-800 to-red-900 text-white p-6 sm:p-7 relative overflow-hidden">
          <div className="absolute -right-6 -bottom-6 w-36 h-36 bg-white/5 rounded-full pointer-events-none" />

          <div className="flex items-center justify-between gap-3 mb-2">
            <span className="px-2.5 py-1 bg-white/20 backdrop-blur-xs text-white text-[11px] font-bold rounded-md tracking-wider uppercase flex items-center gap-1.5">
              <QrCode className="w-3.5 h-3.5" />
              <span>DAFTAR HADIR VIA BARCODE</span>
            </span>
            <span className={`px-2.5 py-1 rounded-md text-xs font-bold ${
              event.status === 'Aktif' 
                ? 'bg-emerald-500 text-white shadow-xs' 
                : 'bg-gray-700 text-gray-200'
            }`}>
              {event.status === 'Aktif' ? '● Absensi Terbuka' : 'Ditutup'}
            </span>
          </div>

          <h1 className="text-xl sm:text-2xl font-extrabold text-white leading-snug tracking-tight">
            {event.namaKegiatan}
          </h1>

          {/* Meta Details */}
          <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-red-100">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-amber-300 shrink-0" />
              <span>{event.tanggal}</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-300 shrink-0" />
              <span>{event.waktu}</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-amber-300 shrink-0" />
              <span className="truncate">{event.lokasi}</span>
            </div>
            <div className="flex items-center gap-2">
              <Building2 className="w-4 h-4 text-amber-300 shrink-0" />
              <span className="truncate">{event.penyelenggara}</span>
            </div>
          </div>
        </div>

        {/* Offline notification if network is down */}
        {!isConnected && (
          <div className="p-3 bg-amber-500 text-slate-950 text-xs font-semibold flex items-center gap-2 px-6">
            <WifiOff className="w-4 h-4 shrink-0" />
            <span>Koneksi internet bermasalah. Untuk memastikan data langsung masuk ke server, perangkat peserta membutuhkan koneksi internet.</span>
          </div>
        )}

        {/* Status: INACTIVE NOTICE */}
        {event.status !== 'Aktif' ? (
          <div className="p-8 text-center space-y-4">
            <div className="w-14 h-14 bg-gray-100 text-gray-500 rounded-full flex items-center justify-center mx-auto">
              <AlertCircle className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-gray-800">Pendaftaran Kehadiran Telah Ditutup</h3>
              <p className="text-gray-500 text-sm mt-1 max-w-sm mx-auto">
                Pendaftaran kehadiran untuk kegiatan ini telah ditutup oleh pengurus PGRI.
              </p>
            </div>
            <div className="pt-4 border-t border-gray-100">
              <button
                onClick={onNavigateToLogin}
                className="text-xs text-red-700 hover:text-red-900 font-bold"
              >
                Login Admin PGRI &rarr;
              </button>
            </div>
          </div>
        ) : (
          /* FORM SUBMISSION */
          <form onSubmit={handleSubmit} className="p-6 sm:p-7 space-y-5">
            {/* Instruction */}
            <div className="p-3 bg-red-50/70 border border-red-100 rounded-xl text-xs text-red-900 flex items-center gap-2.5">
              <UserCheck className="w-4 h-4 text-red-700 shrink-0" />
              <span>Silakan isi data kehadiran Anda di bawah ini dengan lengkap dan benar.</span>
            </div>

            {/* Error Message Alert */}
            {errorMessage && (
              <div className="p-3.5 bg-red-50 text-red-700 border border-red-200 rounded-xl text-xs sm:text-sm font-medium flex items-start gap-2.5 animate-in fade-in">
                <AlertCircle className="w-5 h-5 shrink-0 text-red-600 mt-0.5" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Field: Nama Lengkap */}
            <div>
              <label className="block text-xs sm:text-sm font-bold text-gray-800 mb-1">
                Nama Lengkap (beserta gelar jika ada) <span className="text-red-600">*</span>
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-gray-400 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  value={nama}
                  onChange={(e) => {
                    setNama(e.target.value);
                    if (errorMessage) setErrorMessage('');
                  }}
                  placeholder="Contoh: Ahmad Fauzi, S.Pd."
                  className="w-full pl-10 pr-4 py-3 text-base border-2 border-gray-300 rounded-xl focus:border-red-600 focus:ring-0 focus:outline-hidden transition-colors"
                  required
                />
              </div>
              <p className="text-[11px] text-gray-400 mt-1">Minimal 3 karakter.</p>
            </div>

            {/* Field: Asal Sekolah */}
            <div>
              <label className="block text-xs sm:text-sm font-bold text-gray-800 mb-1">
                Asal Sekolah / Unit Kerja <span className="text-red-600">*</span>
              </label>
              <div className="relative">
                <School className="w-4 h-4 text-gray-400 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  value={asalSekolah}
                  onChange={(e) => {
                    setAsalSekolah(e.target.value);
                    if (errorMessage) setErrorMessage('');
                  }}
                  placeholder="Contoh: SD Negeri 2 Jetis"
                  className="w-full pl-10 pr-4 py-3 text-base border-2 border-gray-300 rounded-xl focus:border-red-600 focus:ring-0 focus:outline-hidden transition-colors"
                  required
                />
              </div>
            </div>

            {/* Field: Jabatan (Manual text entry) */}
            <div>
              <label className="block text-xs sm:text-sm font-bold text-gray-800 mb-1">
                Jabatan <span className="text-red-600">*</span>
              </label>
              <div className="relative">
                <Briefcase className="w-4 h-4 text-gray-400 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  value={jabatan}
                  onChange={(e) => {
                    setJabatan(e.target.value);
                    if (errorMessage) setErrorMessage('');
                  }}
                  placeholder="Contoh: Guru Kelas, Kepala Sekolah, Sekretaris Cabang, Anggota..."
                  className="w-full pl-10 pr-4 py-3 text-base border-2 border-gray-300 rounded-xl focus:border-red-600 focus:ring-0 focus:outline-hidden transition-colors"
                  required
                />
              </div>
              <p className="text-[11px] text-gray-400 mt-1">Ketik jabatan Anda secara manual.</p>
            </div>

            {/* Submit Button with Anti Double Click state */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={isSubmitting}
                className={`w-full py-4 text-base font-extrabold rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 select-none active:scale-[0.98] ${
                  isSubmitting
                    ? 'bg-gray-400 text-gray-100 cursor-not-allowed'
                    : 'bg-red-700 hover:bg-red-800 text-white shadow-red-700/25'
                }`}
              >
                {isSubmitting ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>MENYIMPAN...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-5 h-5" />
                    <span>HADIR</span>
                  </>
                )}
              </button>
            </div>

            {/* Footer note */}
            <p className="text-center text-[11px] text-gray-400 pt-2">
              Waktu kehadiran dan nomor urut peserta akan dicatat otomatis oleh sistem.
            </p>
          </form>
        )}
      </div>

      {/* Bottom helper */}
      <div className="mt-6 text-center text-xs text-gray-500">
        <p>PGRI — Persatuan Guru Republik Indonesia</p>
        <button
          onClick={onNavigateToLogin}
          className="mt-2 text-red-700 font-semibold hover:underline inline-flex items-center gap-1"
        >
          Login Administrator PGRI
        </button>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Download, 
  Calendar, 
  MapPin, 
  Building2, 
  Users, 
  Clock, 
  FileSpreadsheet, 
  CheckCircle2,
  Printer
} from 'lucide-react';
import { PGRIEvent, AttendanceRecord } from '../types';
import { getEvents } from '../services/eventService';
import { getAllAttendanceRecords } from '../services/attendanceService';
import { generateAttendancePDF, exportAttendanceToCSV } from '../services/pdfService';

interface Props {
  initialEventId?: string;
}

export const ReportView: React.FC<Props> = ({ initialEventId }) => {
  const [events, setEvents] = useState<PGRIEvent[]>([]);
  const [selectedEventId, setSelectedEventId] = useState<string>(initialEventId || '');
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [isExportingPdf, setIsExportingPdf] = useState<boolean>(false);
  const [isExportingCsv, setIsExportingCsv] = useState<boolean>(false);

  useEffect(() => {
    getEvents().then(all => {
      setEvents(all);
      if (!selectedEventId && all.length > 0) {
        setSelectedEventId(all[0].id);
      }
    });
  }, [selectedEventId]);

  useEffect(() => {
    if (!selectedEventId) return;

    setLoading(true);
    getAllAttendanceRecords(selectedEventId).then(data => {
      setRecords(data);
      setLoading(false);
    });
  }, [selectedEventId]);

  const activeEvent = events.find(e => e.id === selectedEventId) || null;

  const handleDownloadPDF = () => {
    if (!activeEvent) return;
    setIsExportingPdf(true);
    setTimeout(() => {
      try {
        generateAttendancePDF(activeEvent, records);
      } catch (err) {
        console.error("Gagal export PDF:", err);
        alert("Gagal membuat dokumen PDF.");
      } finally {
        setIsExportingPdf(false);
      }
    }, 150);
  };

  const handleExportCSV = () => {
    if (!activeEvent) return;
    setIsExportingCsv(true);
    setTimeout(() => {
      try {
        exportAttendanceToCSV(activeEvent, records);
      } catch (err) {
        console.error("Gagal export CSV:", err);
      } finally {
        setIsExportingCsv(false);
      }
    }, 150);
  };

  if (events.length === 0) {
    return (
      <div className="bg-white rounded-2xl p-12 text-center border border-gray-200">
        <FileText className="w-12 h-12 mx-auto text-gray-300 mb-3" />
        <h3 className="text-base font-bold text-gray-800">Belum Ada Agenda Kegiatan</h3>
        <p className="text-xs text-gray-500 mt-1">Buat kegiatan terlebih dahulu untuk mencetak laporan kehadiran.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      
      {/* Top Selector Card */}
      <div className="bg-white p-5 rounded-2xl shadow-xs border border-gray-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
            Pilih Agenda Kegiatan Untuk Laporan:
          </label>
          <select
            value={selectedEventId}
            onChange={(e) => setSelectedEventId(e.target.value)}
            className="w-full sm:max-w-md text-sm font-bold text-gray-800 bg-gray-50 border-2 border-gray-200 rounded-xl px-3 py-2.5 focus:border-red-600 focus:outline-hidden"
          >
            {events.map((ev) => (
              <option key={ev.id} value={ev.id}>
                {ev.namaKegiatan} — {ev.tanggal} ({ev.status})
              </option>
            ))}
          </select>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleExportCSV}
            disabled={isExportingCsv || !activeEvent}
            className="px-4 py-2.5 bg-white border-2 border-gray-300 hover:border-emerald-600 text-gray-700 hover:text-emerald-700 text-xs sm:text-sm font-bold rounded-xl transition-all shadow-xs flex items-center gap-2"
            title="Download Format Spreadsheet CSV"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>{isExportingCsv ? 'Menyiapkan...' : 'Export CSV'}</span>
          </button>

          <button
            onClick={handleDownloadPDF}
            disabled={isExportingPdf || !activeEvent}
            className="px-5 py-2.5 bg-red-700 hover:bg-red-800 text-white text-xs sm:text-sm font-bold rounded-xl shadow-md transition-all flex items-center gap-2"
          >
            {isExportingPdf ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>MEMPROSES PDF...</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>DOWNLOAD PDF (A4)</span>
              </>
            )}
          </button>
        </div>
      </div>

      {activeEvent && (
        <div className="bg-white rounded-2xl shadow-xl border border-gray-200 overflow-hidden">
          
          {/* Official Letterhead Preview */}
          <div className="p-6 sm:p-8 border-b-2 border-red-700 bg-gray-50/50">
            <div className="text-center max-w-2xl mx-auto space-y-1">
              <span className="text-red-700 font-extrabold text-sm sm:text-base tracking-widest uppercase">
                PERSATUAN GURU REPUBLIK INDONESIA (PGRI)
              </span>
              <h1 className="text-xl sm:text-2xl font-black text-gray-900 tracking-tight">
                DAFTAR HADIR PESERTA KEGIATAN
              </h1>
              <p className="text-xs text-gray-500 font-medium">
                Rekapitulasi Absensi Resmi Dokumen Pertanggungjawaban Kegiatan
              </p>
            </div>

            {/* Event Details Grid */}
            <div className="mt-6 bg-white p-4 rounded-xl border border-gray-200 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs text-gray-700">
              <div>
                <span className="text-[10px] uppercase font-bold text-gray-400 block">Nama Kegiatan</span>
                <span className="font-bold text-gray-900 text-sm">{activeEvent.namaKegiatan}</span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-gray-400 block">Tanggal & Waktu</span>
                <span className="font-semibold text-gray-800">{activeEvent.tanggal} • {activeEvent.waktu}</span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-gray-400 block">Lokasi & Penyelenggara</span>
                <span className="font-semibold text-gray-800">{activeEvent.lokasi} ({activeEvent.penyelenggara})</span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-gray-400 block">Total Peserta Hadir</span>
                <span className="font-extrabold text-red-700 text-base">{records.length} Orang</span>
              </div>
            </div>
          </div>

          {/* Table Preview */}
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-gray-800 flex items-center gap-2">
                <span>Pratinjau Tabel Kehadiran</span>
                <span className="px-2 py-0.5 text-xs bg-red-100 text-red-800 rounded-full font-bold">
                  {records.length} Baris
                </span>
              </h3>
              <p className="text-xs text-gray-400">Format cetak A4 otomatis membagi halaman bertanda tangan</p>
            </div>

            {loading ? (
              <div className="py-12 text-center text-gray-500">
                <div className="w-8 h-8 border-4 border-red-700 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                <p className="text-xs font-semibold">Memuat rekapitulasi data...</p>
              </div>
            ) : records.length === 0 ? (
              <div className="py-12 text-center text-gray-400 bg-gray-50 rounded-xl">
                <Users className="w-10 h-10 mx-auto text-gray-300 mb-2" />
                <p className="text-sm font-bold text-gray-600">Belum ada peserta yang hadir</p>
                <p className="text-xs text-gray-400">PDF akan dicetak dalam format formulir kosong jika diunduh sekarang.</p>
              </div>
            ) : (
              <div className="overflow-x-auto border border-gray-200 rounded-xl">
                <table className="w-full text-left text-xs sm:text-sm">
                  <thead className="bg-red-700 text-white text-[11px] uppercase tracking-wider font-bold">
                    <tr>
                      <th className="py-3 px-3 text-center w-10">No</th>
                      <th className="py-3 px-3 w-20">Nomor</th>
                      <th className="py-3 px-4">Nama Lengkap</th>
                      <th className="py-3 px-4">Asal Sekolah / Unit</th>
                      <th className="py-3 px-4">Jabatan</th>
                      <th className="py-3 px-4 text-center w-28">Waktu Hadir</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 text-gray-800">
                    {records.map((r, i) => (
                      <tr key={r.id} className="hover:bg-gray-50">
                        <td className="py-2.5 px-3 text-center text-gray-400 font-mono text-xs">{i + 1}</td>
                        <td className="py-2.5 px-3 font-mono font-bold text-red-700">{r.nomor}</td>
                        <td className="py-2.5 px-4 font-bold text-gray-900">{r.nama}</td>
                        <td className="py-2.5 px-4 text-gray-600">{r.asalSekolah}</td>
                        <td className="py-2.5 px-4 text-gray-700">{r.jabatanPGRI}</td>
                        <td className="py-2.5 px-4 text-center font-mono text-xs font-semibold text-emerald-700">{r.waktuHadir}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Bottom Signature Area Preview */}
            <div className="mt-8 pt-6 border-t border-gray-200 flex flex-col sm:flex-row justify-between items-end gap-6 text-xs text-gray-600">
              <div>
                <p>Dicetak secara otomatis melalui:</p>
                <p className="font-bold text-gray-900">PGRI ATTENDANCE SYSTEM</p>
                <p className="text-[11px] text-gray-400">Standar Dokumen Resmi Persatuan Guru Republik Indonesia</p>
              </div>

              <div className="text-center min-w-[200px] space-y-1">
                <p>Mengetahui,</p>
                <p className="font-bold text-gray-900">Pengurus PGRI</p>
                <div className="h-16 flex items-end justify-center">
                  <div className="w-48 border-b border-gray-400" />
                </div>
                <p className="text-[11px] text-gray-500">( .................................................... )</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

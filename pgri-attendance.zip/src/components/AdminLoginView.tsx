import React, { useState } from 'react';
import { Shield, Lock, User, AlertCircle, ArrowLeft, LogIn, CheckCircle2 } from 'lucide-react';
import { useFirebase } from '../firebase/context';

interface Props {
  onLoginSuccess: () => void;
  onBackToAttendance: () => void;
  onOpenConfig: () => void;
}

export const AdminLoginView: React.FC<Props> = ({ 
  onLoginSuccess, 
  onBackToAttendance 
}) => {
  const { loginAsPreviewAdmin } = useFirebase();

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    const cleanUsername = username.trim().toLowerCase();
    const cleanPassword = password.trim();

    if (!cleanUsername || !cleanPassword) {
      setErrorMessage('Silakan masukkan ID Admin dan Password.');
      return;
    }

    setLoading(true);

    setTimeout(() => {
      // Validate credentials as requested: Admin: admin, Password: pgribesuki
      if (cleanUsername === 'admin' && cleanPassword === 'pgribesuki') {
        loginAsPreviewAdmin('admin@pgribesuki.id', 'Administrator PGRI Besuki');
        setLoading(false);
        onLoginSuccess();
      } else {
        setLoading(false);
        setErrorMessage('ID Admin atau Password tidak sesuai. Silakan periksa kembali.');
      }
    }, 300);
  };

  return (
    <div className="max-w-md mx-auto my-10 px-4">
      <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
        
        {/* Header */}
        <div className="bg-red-700 text-white p-6 sm:p-7 text-center relative">
          <button
            onClick={onBackToAttendance}
            className="absolute left-4 top-4 p-2 text-white/80 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
            title="Kembali ke formulir absensi"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="w-14 h-14 bg-white rounded-full flex items-center justify-center mx-auto mb-3 shadow-md border-2 border-amber-400">
            <Shield className="w-7 h-7 text-red-700" />
          </div>

          <h2 className="text-xl font-bold tracking-tight">LOGIN ADMIN PGRI</h2>
          <p className="text-xs text-red-100 mt-1">
            Panel Pengelolaan Kegiatan & Presensi Barcode
          </p>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 sm:p-7 space-y-4">
          {errorMessage && (
            <div className="p-3 text-xs bg-red-50 text-red-700 border border-red-200 rounded-xl flex items-start gap-2 animate-in fade-in">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600 mt-0.5" />
              <div className="flex-1 font-medium">
                <span>{errorMessage}</span>
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1">
              Admin / Username
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-gray-400 absolute left-3.5 top-3.5" />
              <input
                type="text"
                value={username}
                onChange={(e) => {
                  setUsername(e.target.value);
                  if (errorMessage) setErrorMessage('');
                }}
                placeholder="Masukkan ID: admin"
                className="w-full pl-10 pr-4 py-2.5 text-sm border-2 border-gray-300 rounded-xl focus:border-red-600 focus:outline-hidden font-medium"
                required
                autoFocus
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1">
              Password
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-gray-400 absolute left-3.5 top-3.5" />
              <input
                type="password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  if (errorMessage) setErrorMessage('');
                }}
                placeholder="Masukkan password..."
                className="w-full pl-10 pr-4 py-2.5 text-sm border-2 border-gray-300 rounded-xl focus:border-red-600 focus:outline-hidden"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-2 py-3 bg-red-700 hover:bg-red-800 text-white font-bold rounded-xl shadow-md transition-colors flex items-center justify-center gap-2 text-sm disabled:bg-gray-400 active:scale-[0.99]"
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>MEMERIKSA AKUN...</span>
              </>
            ) : (
              <>
                <LogIn className="w-4 h-4" />
                <span>Masuk Dashboard</span>
              </>
            )}
          </button>
        </form>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-gray-50 border-t border-gray-100 text-center">
          <button
            type="button"
            onClick={onBackToAttendance}
            className="text-xs font-semibold text-red-700 hover:text-red-900"
          >
            &larr; Kembali ke Halaman Absensi Peserta
          </button>
        </div>
      </div>
    </div>
  );
};

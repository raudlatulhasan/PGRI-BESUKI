import React, { useState, useEffect } from 'react';
import { FirebaseProvider, useFirebase } from './firebase/context';
import { Navbar } from './components/Navbar';
import { FirebaseWarningBanner } from './components/FirebaseWarningBanner';
import { FirebaseConfigModal } from './components/FirebaseConfigModal';
import { ParticipantAttendanceView } from './components/ParticipantAttendanceView';
import { AdminLoginView } from './components/AdminLoginView';
import { AdminDashboard } from './components/AdminDashboard';
import { AdminSidebar } from './components/AdminSidebar';
import { EventManagementView } from './components/EventManagementView';
import { CreateEventView } from './components/CreateEventView';
import { QrCodeGeneratorView } from './components/QrCodeGeneratorView';
import { AttendanceListView } from './components/AttendanceListView';
import { ReportView } from './components/ReportView';
import { PGRIEvent, ActiveTab } from './types';

function MainApp() {
  const { user, previewAdmin, signOut } = useFirebase();

  // URL query params parsing for barcode scanning
  const [urlParams] = useState(() => {
    if (typeof window !== 'undefined') {
      const search = new URLSearchParams(window.location.search);
      return {
        token: search.get('token'),
        event: search.get('event'),
        view: search.get('view')
      };
    }
    return { token: null, event: null, view: null };
  });

  // Active view: 'attendance' (participant form) | 'login' | ActiveTab
  const [currentTab, setCurrentTab] = useState<ActiveTab | 'login' | 'attendance'>(() => {
    if (urlParams.token || urlParams.event) {
      return 'attendance';
    }
    if (urlParams.view === 'admin') {
      return 'dashboard';
    }
    return 'attendance';
  });

  // Selected event for passing between views
  const [selectedEventForQr, setSelectedEventForQr] = useState<PGRIEvent | null>(null);
  const [selectedEventIdForAttendance, setSelectedEventIdForAttendance] = useState<string>(urlParams.event || '');

  // Firebase Config Modal State
  const [isConfigModalOpen, setIsConfigModalOpen] = useState(false);

  // If user logs in successfully, transition to dashboard
  useEffect(() => {
    if ((user || previewAdmin) && currentTab === 'login') {
      setCurrentTab('dashboard');
    }
  }, [user, previewAdmin, currentTab]);

  const isAdminLoggedIn = Boolean(user) || Boolean(previewAdmin);

  const handleSelectTab = (tab: ActiveTab | 'login' | 'attendance') => {
    setCurrentTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLogout = async () => {
    if (window.confirm('Keluar dari panel Admin PGRI?')) {
      await signOut();
      setCurrentTab('attendance');
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans text-gray-800 antialiased selection:bg-red-700 selection:text-white">
      
      {/* Top Firebase Configuration Warning Banner if unconfigured */}
      <FirebaseWarningBanner onOpenConfig={() => setIsConfigModalOpen(true)} />

      {/* Main Navbar */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={handleSelectTab}
        onOpenConfig={() => setIsConfigModalOpen(true)}
        isAdminLoggedIn={isAdminLoggedIn}
      />

      {/* Page Body */}
      <div className="flex-1 flex flex-col">
        {/* If Participant View */}
        {currentTab === 'attendance' && (
          <main className="flex-1">
            <ParticipantAttendanceView
              initialEventId={urlParams.event}
              initialToken={urlParams.token}
              onNavigateToLogin={() => setCurrentTab('login')}
            />
          </main>
        )}

        {/* If Admin Login View */}
        {currentTab === 'login' && (
          <main className="flex-1 flex items-center justify-center py-6">
            <AdminLoginView
              onLoginSuccess={() => setCurrentTab('dashboard')}
              onBackToAttendance={() => setCurrentTab('attendance')}
              onOpenConfig={() => setIsConfigModalOpen(true)}
            />
          </main>
        )}

        {/* If Admin Authenticated Dashboard View */}
        {currentTab !== 'attendance' && currentTab !== 'login' && (
          <div className="flex-1 flex flex-col md:flex-row">
            {/* Desktop Sidebar */}
            <div className="hidden md:block">
              <AdminSidebar
                currentTab={currentTab as ActiveTab}
                onSelectTab={(tab) => handleSelectTab(tab)}
                onOpenConfig={() => setIsConfigModalOpen(true)}
                onLogout={handleLogout}
              />
            </div>

            {/* Admin Content Area */}
            <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl">
              {currentTab === 'dashboard' && (
                <AdminDashboard
                  onNavigateTab={(tab) => handleSelectTab(tab)}
                  onSelectEventForQr={(ev) => {
                    setSelectedEventForQr(ev);
                    handleSelectTab('qrcode');
                  }}
                  onSelectEventForAttendance={(id) => {
                    setSelectedEventIdForAttendance(id);
                    handleSelectTab('attendance-list');
                  }}
                />
              )}

              {currentTab === 'events' && (
                <EventManagementView
                  onCreateEventClick={() => handleSelectTab('create-event')}
                  onSelectEventForQr={(ev) => {
                    setSelectedEventForQr(ev);
                    handleSelectTab('qrcode');
                  }}
                  onSelectEventForAttendance={(id) => {
                    setSelectedEventIdForAttendance(id);
                    handleSelectTab('attendance-list');
                  }}
                />
              )}

              {currentTab === 'create-event' && (
                <CreateEventView
                  onEventCreated={(newEvent) => {
                    setSelectedEventForQr(newEvent);
                    handleSelectTab('qrcode');
                  }}
                  onCancel={() => handleSelectTab('events')}
                />
              )}

              {currentTab === 'qrcode' && (
                <QrCodeGeneratorView
                  selectedEvent={selectedEventForQr}
                  onSelectEvent={(ev) => setSelectedEventForQr(ev)}
                />
              )}

              {currentTab === 'attendance-list' && (
                <AttendanceListView
                  initialEventId={selectedEventIdForAttendance}
                  onNavigateToReport={(id) => {
                    setSelectedEventIdForAttendance(id);
                    handleSelectTab('reports');
                  }}
                />
              )}

              {currentTab === 'reports' && (
                <ReportView initialEventId={selectedEventIdForAttendance} />
              )}
            </main>
          </div>
        )}
      </div>

      {/* Footer (as specified in item 54: PGRI — Persatuan Guru Republik Indonesia) */}
      <footer className="bg-white border-t border-gray-200 py-6 text-center text-xs text-gray-500 print:hidden">
        <div className="max-w-7xl mx-auto px-4 space-y-1">
          <p className="font-extrabold text-red-700 text-sm tracking-wide">
            PGRI ATTENDANCE
          </p>
          <p className="font-medium text-gray-700">
            Sistem Daftar Hadir Online PGRI Berbasis Barcode
          </p>
          <p className="text-gray-400 text-[11px] pt-1">
            PGRI — Persatuan Guru Republik Indonesia &bull; Transformasi Digital Presensi Guru
          </p>
        </div>
      </footer>

      {/* Global Firebase Config Modal */}
      <FirebaseConfigModal
        isOpen={isConfigModalOpen}
        onClose={() => setIsConfigModalOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <FirebaseProvider>
      <MainApp />
    </FirebaseProvider>
  );
}

export interface FirebaseConfig {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket: string;
  messagingSenderId: string;
  appId: string;
  firestoreDatabaseId?: string;
}

export type EventStatus = 'Aktif' | 'Nonaktif';

export interface PGRIEvent {
  id: string;
  namaKegiatan: string;
  tanggal: string; // YYYY-MM-DD
  waktu: string; // e.g. "08:00 WIB"
  lokasi: string;
  penyelenggara: string;
  status: EventStatus;
  qrToken: string;
  createdAt: string;
  createdBy?: string;
}

export interface AttendanceRecord {
  id: string; // often matching nomor or auto doc id
  nomor: string;
  nama: string;
  asalSekolah: string;
  jabatanPGRI: string;
  waktuHadir: string; // e.g. "07:35 WIB"
  tanggalHadir: string; // e.g. "06 Oktober 2026"
  eventId: string;
  createdAt: string;
}

export interface AdminUser {
  uid: string;
  email: string | null;
  nama?: string;
  role: 'admin';
  aktif: boolean;
}

export type ActiveTab = 
  | 'dashboard'
  | 'events'
  | 'create-event'
  | 'qrcode'
  | 'attendance-list'
  | 'reports'
  | 'settings';

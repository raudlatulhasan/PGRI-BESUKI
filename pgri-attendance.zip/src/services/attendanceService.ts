import {
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  query,
  onSnapshot
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType, isFirebaseConfigured } from '../firebase/config';
import { AttendanceRecord } from '../types';

const DEMO_ATTENDANCE_KEY = 'pgri_attendance_demo_records';

const INITIAL_DEMO_ATTENDANCE: AttendanceRecord[] = [
  {
    id: 'demo_att_001',
    nomor: '001',
    nama: 'Ahmad Fauzi, S.Pd.',
    asalSekolah: 'SD Negeri 2 Besuki',
    jabatanPGRI: 'Anggota',
    waktuHadir: '07:35 WIB',
    tanggalHadir: '06 Oktober 2026',
    eventId: 'demo-event-1',
    createdAt: new Date('2026-10-06T07:35:00').toISOString()
  },
  {
    id: 'demo_att_002',
    nomor: '002',
    nama: 'Dra. Hj. Siti Aminah, M.Pd.',
    asalSekolah: 'SMP Negeri 1 Besuki',
    jabatanPGRI: 'Sekretaris',
    waktuHadir: '07:42 WIB',
    tanggalHadir: '06 Oktober 2026',
    eventId: 'demo-event-1',
    createdAt: new Date('2026-10-06T07:42:00').toISOString()
  },
  {
    id: 'demo_att_003',
    nomor: '003',
    nama: 'Bambang Sudarsono, S.Pd., M.M.',
    asalSekolah: 'SMA Negeri 1 Besuki',
    jabatanPGRI: 'Ketua',
    waktuHadir: '07:50 WIB',
    tanggalHadir: '06 Oktober 2026',
    eventId: 'demo-event-1',
    createdAt: new Date('2026-10-06T07:50:00').toISOString()
  }
];

function getDemoAttendance(): AttendanceRecord[] {
  if (typeof window === 'undefined') return INITIAL_DEMO_ATTENDANCE;
  try {
    const data = localStorage.getItem(DEMO_ATTENDANCE_KEY);
    if (data) return JSON.parse(data);
    localStorage.setItem(DEMO_ATTENDANCE_KEY, JSON.stringify(INITIAL_DEMO_ATTENDANCE));
    return INITIAL_DEMO_ATTENDANCE;
  } catch {
    return INITIAL_DEMO_ATTENDANCE;
  }
}

function saveDemoAttendance(records: AttendanceRecord[]) {
  if (typeof window !== 'undefined') {
    localStorage.setItem(DEMO_ATTENDANCE_KEY, JSON.stringify(records));
  }
}

export function formatIndonesianDate(date: Date = new Date()): string {
  const months = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ];
  const day = String(date.getDate()).padStart(2, '0');
  const month = months[date.getMonth()];
  const year = date.getFullYear();
  return `${day} ${month} ${year}`;
}

export function formatIndonesianTime(date: Date = new Date()): string {
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  return `${hours}:${minutes} WIB`;
}

export interface AttendanceSubmissionInput {
  nomor?: string;
  nama: string;
  asalSekolah: string;
  jabatanPGRI: string;
  eventId: string;
}

export async function submitAttendance(input: AttendanceSubmissionInput): Promise<{ success: boolean; record?: AttendanceRecord; error?: string }> {
  const cleanNama = input.nama.trim();
  const cleanSekolah = input.asalSekolah.trim();
  const cleanJabatan = input.jabatanPGRI.trim();

  // Basic validations
  if (!cleanNama || cleanNama.length < 3) {
    return { success: false, error: 'Nama lengkap wajib diisi minimal 3 karakter.' };
  }
  if (!cleanSekolah) {
    return { success: false, error: 'Asal sekolah wajib diisi.' };
  }
  if (!cleanJabatan) {
    return { success: false, error: 'Silakan isi jabatan Anda.' };
  }

  // If using Demo / Fallback mode
  if (!isFirebaseConfigured() || !db) {
    const list = getDemoAttendance();
    const eventRecords = list.filter(r => r.eventId === input.eventId);

    // Duplicate check by name and school (case-insensitive)
    const existingAttendee = eventRecords.find(
      r => r.nama.toLowerCase() === cleanNama.toLowerCase() && 
           r.asalSekolah.toLowerCase() === cleanSekolah.toLowerCase()
    );
    if (existingAttendee) {
      return { success: false, error: 'Anda sudah tercatat hadir pada kegiatan ini.' };
    }

    // Auto-generate nomor if not provided
    let finalNomor = input.nomor ? input.nomor.trim() : '';
    if (!finalNomor) {
      finalNomor = String(eventRecords.length + 1).padStart(3, '0');
    }

    const attendanceDocId = `att_${finalNomor}`;
    const now = new Date();
    const tanggalHadir = formatIndonesianDate(now);
    const waktuHadir = formatIndonesianTime(now);

    const newRecord: AttendanceRecord = {
      id: attendanceDocId,
      nomor: finalNomor,
      nama: cleanNama,
      asalSekolah: cleanSekolah,
      jabatanPGRI: cleanJabatan,
      waktuHadir,
      tanggalHadir,
      eventId: input.eventId,
      createdAt: now.toISOString()
    };

    list.unshift(newRecord);
    saveDemoAttendance(list);
    return { success: true, record: newRecord };
  }

  // Real Firestore Submission
  try {
    // 1. Fetch current attendee records for this event to check duplicates & assign next nomor
    const attendanceCol = collection(db, 'events', input.eventId, 'attendance');
    const existingDocs = await getDocs(attendanceCol);
    const currentAttendees = existingDocs.docs.map(d => d.data() as AttendanceRecord);

    // Check duplicate by name + school
    const isDuplicate = currentAttendees.some(
      r => r.nama.toLowerCase() === cleanNama.toLowerCase() && 
           r.asalSekolah.toLowerCase() === cleanSekolah.toLowerCase()
    );
    if (isDuplicate) {
      return { success: false, error: 'Anda sudah tercatat hadir pada kegiatan ini.' };
    }

    // Auto-generate sequential nomor
    let finalNomor = input.nomor ? input.nomor.trim() : '';
    if (!finalNomor) {
      const nextNum = currentAttendees.length + 1;
      finalNomor = String(nextNum).padStart(3, '0');
    }

    let attendanceDocId = `att_${finalNomor}`;
    // If doc ID already exists in firestore, append unique suffix to avoid collision
    const existingSnap = await getDoc(doc(db, 'events', input.eventId, 'attendance', attendanceDocId));
    if (existingSnap.exists()) {
      attendanceDocId = `att_${finalNomor}_${Date.now().toString().slice(-4)}`;
    }

    const now = new Date();
    const tanggalHadir = formatIndonesianDate(now);
    const waktuHadir = formatIndonesianTime(now);

    const newRecord: AttendanceRecord = {
      id: attendanceDocId,
      nomor: finalNomor,
      nama: cleanNama,
      asalSekolah: cleanSekolah,
      jabatanPGRI: cleanJabatan,
      waktuHadir,
      tanggalHadir,
      eventId: input.eventId,
      createdAt: now.toISOString()
    };

    const attendanceDocRef = doc(db, 'events', input.eventId, 'attendance', attendanceDocId);
    await setDoc(attendanceDocRef, newRecord);
    return { success: true, record: newRecord };
  } catch (err: unknown) {
    console.warn("Notice submitting attendance to Firestore:", err);
    // Fallback save locally so user attendance is never lost
    const list = getDemoAttendance();
    const now = new Date();
    const tanggalHadir = formatIndonesianDate(now);
    const waktuHadir = formatIndonesianTime(now);
    const fallbackRecord: AttendanceRecord = {
      id: `att_${Date.now()}`,
      nomor: String(list.length + 1).padStart(3, '0'),
      nama: cleanNama,
      asalSekolah: cleanSekolah,
      jabatanPGRI: cleanJabatan,
      waktuHadir,
      tanggalHadir,
      eventId: input.eventId,
      createdAt: now.toISOString()
    };
    list.unshift(fallbackRecord);
    saveDemoAttendance(list);
    return { success: true, record: fallbackRecord };
  }
}

export function subscribeToEventAttendance(
  eventId: string, 
  callback: (records: AttendanceRecord[]) => void,
  onError?: (err: Error) => void
) {
  if (!isFirebaseConfigured() || !db) {
    const list = getDemoAttendance().filter(r => r.eventId === eventId);
    callback(list);
    return () => {};
  }

  const attendanceCol = collection(db, 'events', eventId, 'attendance');
  const q = query(attendanceCol);

  return onSnapshot(
    q,
    (snapshot) => {
      const records = snapshot.docs.map(doc => doc.data() as AttendanceRecord);
      records.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      callback(records);
    },
    (err) => {
      console.warn("Notice in subscribeToEventAttendance:", err);
      if (onError) onError(err);
      const list = getDemoAttendance().filter(r => r.eventId === eventId);
      callback(list);
    }
  );
}

export async function getAllAttendanceRecords(eventId: string): Promise<AttendanceRecord[]> {
  if (!isFirebaseConfigured() || !db) {
    return getDemoAttendance().filter(r => r.eventId === eventId);
  }

  try {
    const attendanceCol = collection(db, 'events', eventId, 'attendance');
    const snapshot = await getDocs(attendanceCol);
    const records = snapshot.docs.map(doc => doc.data() as AttendanceRecord);
    records.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return records;
  } catch (err) {
    console.warn("Gagal getAllAttendanceRecords:", err);
    return getDemoAttendance().filter(r => r.eventId === eventId);
  }
}

export async function updateAttendanceRecord(
  eventId: string, 
  recordId: string, 
  data: Partial<Pick<AttendanceRecord, 'nama' | 'asalSekolah' | 'jabatanPGRI'>>
): Promise<void> {
  if (!isFirebaseConfigured() || !db) {
    const list = getDemoAttendance().map(r => {
      if (r.eventId === eventId && r.id === recordId) {
        return { ...r, ...data };
      }
      return r;
    });
    saveDemoAttendance(list);
    return;
  }

  try {
    const ref = doc(db, 'events', eventId, 'attendance', recordId);
    await updateDoc(ref, data);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `events/${eventId}/attendance/${recordId}`);
  }
}

export async function deleteAttendanceRecord(eventId: string, recordId: string): Promise<void> {
  if (!isFirebaseConfigured() || !db) {
    const list = getDemoAttendance().filter(r => !(r.eventId === eventId && r.id === recordId));
    saveDemoAttendance(list);
    return;
  }

  try {
    const ref = doc(db, 'events', eventId, 'attendance', recordId);
    await deleteDoc(ref);
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `events/${eventId}/attendance/${recordId}`);
  }
}

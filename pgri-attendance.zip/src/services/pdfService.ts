import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { PGRIEvent, AttendanceRecord } from '../types';

export function generateAttendancePDF(event: PGRIEvent, records: AttendanceRecord[]): void {
  // Create A4 portrait document (210 x 297 mm)
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 14;

  // Header Background decoration
  doc.setFillColor(185, 28, 28); // PGRI Red #B91C1C
  doc.rect(margin, 12, pageWidth - (margin * 2), 2, 'F');

  // PGRI Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.setTextColor(185, 28, 28);
  doc.text('PERSATUAN GURU REPUBLIK INDONESIA (PGRI)', pageWidth / 2, 20, { align: 'center' });

  doc.setFontSize(12);
  doc.setTextColor(31, 41, 55); // Gray-800
  doc.text('DAFTAR HADIR PESERTA KEGIATAN', pageWidth / 2, 26, { align: 'center' });

  // Divider line
  doc.setDrawColor(209, 213, 219);
  doc.setLineWidth(0.5);
  doc.line(margin, 30, pageWidth - margin, 30);

  // Event Details Box
  doc.setFillColor(249, 250, 251);
  doc.roundedRect(margin, 33, pageWidth - (margin * 2), 25, 2, 2, 'F');
  doc.setDrawColor(229, 231, 235);
  doc.roundedRect(margin, 33, pageWidth - (margin * 2), 25, 2, 2, 'S');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(55, 65, 81);
  doc.text('Nama Kegiatan', margin + 4, 39);
  doc.text('Tanggal', margin + 4, 45);
  doc.text('Waktu', margin + 4, 51);

  doc.text('Lokasi', margin + 95, 39);
  doc.text('Penyelenggara', margin + 95, 45);
  doc.text('Total Peserta', margin + 95, 51);

  doc.setFont('helvetica', 'normal');
  doc.text(`: ${event.namaKegiatan}`, margin + 30, 39);
  doc.text(`: ${event.tanggal}`, margin + 30, 45);
  doc.text(`: ${event.waktu}`, margin + 30, 51);

  doc.text(`: ${event.lokasi}`, margin + 120, 39);
  doc.text(`: ${event.penyelenggara}`, margin + 120, 45);
  doc.text(`: ${records.length} Orang`, margin + 120, 51);

  // Table Data
  const tableData = records.map((record, index) => [
    index + 1,
    record.nomor,
    record.nama,
    record.asalSekolah,
    record.jabatanPGRI,
    record.waktuHadir
  ]);

  // If empty list, add empty placeholder row
  if (tableData.length === 0) {
    tableData.push(['-', '-', 'Belum ada peserta hadir', '-', '-', '-'] as unknown as (string | number)[]);
  }

  // Render Table with autoTable
  autoTable(doc, {
    startY: 62,
    head: [['No', 'Nomor', 'Nama Lengkap', 'Asal Sekolah / Unit', 'Jabatan', 'Waktu Hadir']],
    body: tableData,
    margin: { left: margin, right: margin, bottom: 45 },
    theme: 'grid',
    headStyles: {
      fillColor: [185, 28, 28], // PGRI Red
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 9,
      halign: 'center'
    },
    bodyStyles: {
      fontSize: 8.5,
      textColor: [31, 41, 55],
      valign: 'middle'
    },
    columnStyles: {
      0: { cellWidth: 10, halign: 'center' },
      1: { cellWidth: 18, halign: 'center' },
      2: { cellWidth: 50 },
      3: { cellWidth: 44 },
      4: { cellWidth: 34 },
      5: { cellWidth: 26, halign: 'center' }
    },
    alternateRowStyles: {
      fillColor: [249, 250, 251]
    },
    didDrawPage: (data) => {
      // Footer page numbering
      doc.setFontSize(8);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(156, 163, 175);
      const str = `Halaman ${data.pageNumber} dari ${doc.getNumberOfPages()}`;
      doc.text(str, pageWidth / 2, pageHeight - 8, { align: 'center' });
      doc.text('PGRI Attendance System - Dokumen Resmi Kehadiran', margin, pageHeight - 8);
    }
  });

  // Calculate signature placement on last page
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const finalY = (doc as any).lastAutoTable ? (doc as any).lastAutoTable.finalY + 12 : 120;
  
  // If remaining space on the page is less than 40mm, add new page for signature
  if (pageHeight - finalY < 45) {
    doc.addPage();
  }

  const sigY = pageHeight - finalY < 45 ? 25 : finalY;
  const sigX = pageWidth - margin - 65;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(31, 41, 55);
  doc.text(`Dicetak pada: ${new Date().toLocaleDateString('id-ID')}`, margin, sigY);
  
  doc.text('Mengetahui,', sigX, sigY);
  doc.setFont('helvetica', 'bold');
  doc.text('Pengurus PGRI', sigX, sigY + 5);

  // Signature space line
  doc.setDrawColor(75, 85, 99);
  doc.setLineWidth(0.3);
  doc.line(sigX, sigY + 28, sigX + 55, sigY + 28);
  doc.setFont('helvetica', 'normal');
  doc.text('( .................................................... )', sigX, sigY + 32);

  // Save the PDF file
  const sanitizedName = event.namaKegiatan.replace(/[^a-zA-Z0-9_-]/g, '_').substring(0, 30);
  const filename = `Daftar_Hadir_${sanitizedName}_${event.tanggal}.pdf`;
  doc.save(filename);
}

export function exportAttendanceToCSV(event: PGRIEvent, records: AttendanceRecord[]): void {
  const headers = ['No', 'Nomor Peserta', 'Nama Lengkap', 'Asal Sekolah', 'Jabatan', 'Tanggal Hadir', 'Waktu Hadir'];
  const rows = records.map((r, i) => [
    i + 1,
    `"${r.nomor}"`,
    `"${r.nama.replace(/"/g, '""')}"`,
    `"${r.asalSekolah.replace(/"/g, '""')}"`,
    `"${r.jabatanPGRI.replace(/"/g, '""')}"`,
    `"${r.tanggalHadir}"`,
    `"${r.waktuHadir}"`
  ]);

  const csvContent = [
    `# DAFTAR HADIR - ${event.namaKegiatan}`,
    `# Tanggal: ${event.tanggal} | Waktu: ${event.waktu} | Lokasi: ${event.lokasi}`,
    headers.join(','),
    ...rows.map(row => row.join(','))
  ].join('\r\n');

  const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  const sanitizedName = event.namaKegiatan.replace(/[^a-zA-Z0-9_-]/g, '_').substring(0, 30);
  link.setAttribute('download', `Daftar_Hadir_${sanitizedName}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

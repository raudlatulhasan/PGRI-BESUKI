import QRCode from 'qrcode';
import { PGRIEvent } from '../types';

export function getAttendanceUrl(event: PGRIEvent): string {
  if (typeof window === 'undefined') {
    return `https://pgri-attendance.web.app/?token=${event.qrToken}&event=${event.id}`;
  }
  const base = `${window.location.origin}${window.location.pathname}`;
  return `${base}?token=${event.qrToken}&event=${event.id}`;
}

export async function generateQrDataUrl(text: string): Promise<string> {
  try {
    return await QRCode.toDataURL(text, {
      width: 450,
      margin: 2,
      color: {
        dark: '#1F2937', // crisp dark slate
        light: '#FFFFFF'
      },
      errorCorrectionLevel: 'H'
    });
  } catch (err) {
    console.error("Gagal generate QR Code:", err);
    throw err;
  }
}

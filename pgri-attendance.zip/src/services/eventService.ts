import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  updateDoc, 
  deleteDoc, 
  query, 
  where,
  onSnapshot,
  orderBy
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType, isFirebaseConfigured } from '../firebase/config';
import { PGRIEvent } from '../types';

const EVENTS_COLLECTION = 'events';

// Local storage demo fallback store for testing when Firebase config is not yet supplied
const DEMO_EVENTS_KEY = 'pgri_attendance_demo_events';

export const INITIAL_DEMO_EVENTS: PGRIEvent[] = [
  {
    id: 'demo-event-1',
    namaKegiatan: 'Rapat Kerja PGRI Cabang Besuki',
    tanggal: '2026-10-06',
    waktu: '08:00 WIB',
    lokasi: 'Aula Gedung Guru PGRI Cabang Besuki',
    penyelenggara: 'Pengurus PGRI Cabang Besuki',
    status: 'Aktif',
    qrToken: 'TOKEN-BESUKI-2026',
    createdAt: new Date().toISOString()
  },
  {
    id: 'demo-event-2',
    namaKegiatan: 'Workshop Pemanfaatan Media Digital Guru Penggerak',
    tanggal: '2026-10-12',
    waktu: '09:00 WIB',
    lokasi: 'Auditorium Ki Hajar Dewantara',
    penyelenggara: 'PGRI Kabupaten',
    status: 'Aktif',
    qrToken: 'TOKEN-WORKSHOP-PGRI',
    createdAt: new Date().toISOString()
  }
];

function getDemoEvents(): PGRIEvent[] {
  if (typeof window === 'undefined') return INITIAL_DEMO_EVENTS;
  try {
    const data = localStorage.getItem(DEMO_EVENTS_KEY);
    if (data) return JSON.parse(data);
    localStorage.setItem(DEMO_EVENTS_KEY, JSON.stringify(INITIAL_DEMO_EVENTS));
    return INITIAL_DEMO_EVENTS;
  } catch {
    return INITIAL_DEMO_EVENTS;
  }
}

function saveDemoEvents(events: PGRIEvent[]) {
  if (typeof window !== 'undefined') {
    localStorage.setItem(DEMO_EVENTS_KEY, JSON.stringify(events));
  }
}

// Generate unique alphanumeric token for QR
export function generateUniqueToken(prefix: string = 'PGRI'): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let token = `${prefix}-`;
  for (let i = 0; i < 8; i++) {
    token += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return token;
}

// Generate unique ID
export function generateId(prefix: string = 'evt'): string {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
}

export async function createEvent(data: Omit<PGRIEvent, 'id' | 'qrToken' | 'createdAt'>): Promise<PGRIEvent> {
  const eventId = generateId('evt');
  const qrToken = generateUniqueToken('PGRI');
  const now = new Date().toISOString();

  const newEvent: PGRIEvent = {
    ...data,
    id: eventId,
    qrToken,
    createdAt: now
  };

  if (!isFirebaseConfigured() || !db) {
    const demo = getDemoEvents();
    demo.unshift(newEvent);
    saveDemoEvents(demo);
    return newEvent;
  }

  try {
    const eventRef = doc(db, EVENTS_COLLECTION, eventId);
    await setDoc(eventRef, newEvent);
    return newEvent;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `${EVENTS_COLLECTION}/${eventId}`);
  }
}

export async function getEvents(): Promise<PGRIEvent[]> {
  if (!isFirebaseConfigured() || !db) {
    return getDemoEvents();
  }

  const firestoreDb = db;
  try {
    const eventsRef = collection(firestoreDb, EVENTS_COLLECTION);
    const snapshot = await getDocs(eventsRef);
    if (snapshot.empty) {
      // Auto seed initial event into Firestore
      const initialEvent = INITIAL_DEMO_EVENTS[0];
      await setDoc(doc(firestoreDb, EVENTS_COLLECTION, initialEvent.id), initialEvent);
      return [initialEvent];
    }
    const events = snapshot.docs.map(doc => doc.data() as PGRIEvent);
    events.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return events;
  } catch (err) {
    console.warn("Gagal getEvents dari Firestore:", err);
    return getDemoEvents();
  }
}

export function subscribeToEvents(callback: (events: PGRIEvent[]) => void, onError?: (err: Error) => void) {
  if (!isFirebaseConfigured() || !db) {
    callback(getDemoEvents());
    return () => {};
  }

  const firestoreDb = db;
  const eventsRef = collection(firestoreDb, EVENTS_COLLECTION);
  return onSnapshot(
    eventsRef,
    async (snapshot) => {
      if (snapshot.empty) {
        try {
          const initialEvent = INITIAL_DEMO_EVENTS[0];
          await setDoc(doc(firestoreDb, EVENTS_COLLECTION, initialEvent.id), initialEvent);
          callback([initialEvent]);
          return;
        } catch {
          callback(getDemoEvents());
          return;
        }
      }
      const events = snapshot.docs.map(doc => doc.data() as PGRIEvent);
      events.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      callback(events);
    },
    (err) => {
      console.warn("Notice in subscribeToEvents:", err);
      if (onError) onError(err);
      callback(getDemoEvents());
    }
  );
}

export async function getEventById(id: string): Promise<PGRIEvent | null> {
  if (!isFirebaseConfigured() || !db) {
    const demo = getDemoEvents();
    return demo.find(e => e.id === id) || null;
  }

  const firestoreDb = db;
  try {
    const eventDoc = await getDoc(doc(firestoreDb, EVENTS_COLLECTION, id));
    if (!eventDoc.exists()) {
      const demo = getDemoEvents();
      return demo.find(e => e.id === id) || null;
    }
    return eventDoc.data() as PGRIEvent;
  } catch (err) {
    console.warn("Gagal getEventById:", err);
    const demo = getDemoEvents();
    return demo.find(e => e.id === id) || null;
  }
}

export async function getActiveEvents(): Promise<PGRIEvent[]> {
  if (!isFirebaseConfigured() || !db) {
    return getDemoEvents().filter(e => e.status === 'Aktif');
  }

  const firestoreDb = db;
  try {
    const eventsRef = collection(firestoreDb, EVENTS_COLLECTION);
    const snapshot = await getDocs(eventsRef);
    if (snapshot.empty) {
      const initialEvent = INITIAL_DEMO_EVENTS[0];
      await setDoc(doc(firestoreDb, EVENTS_COLLECTION, initialEvent.id), initialEvent);
      return [initialEvent];
    }
    const active = snapshot.docs
      .map(doc => doc.data() as PGRIEvent)
      .filter(e => e.status === 'Aktif');
    return active.length > 0 ? active : snapshot.docs.map(d => d.data() as PGRIEvent);
  } catch (err) {
    console.warn("Gagal getActiveEvents:", err);
    return getDemoEvents().filter(e => e.status === 'Aktif');
  }
}

export async function getEventByToken(qrToken: string): Promise<PGRIEvent | null> {
  if (!isFirebaseConfigured() || !db) {
    const demo = getDemoEvents();
    return demo.find(e => e.qrToken === qrToken) || null;
  }

  const firestoreDb = db;
  try {
    const eventsRef = collection(firestoreDb, EVENTS_COLLECTION);
    const snapshot = await getDocs(eventsRef);
    const matched = snapshot.docs
      .map(d => d.data() as PGRIEvent)
      .find(e => e.qrToken === qrToken);
    if (matched) return matched;

    const demo = getDemoEvents();
    return demo.find(e => e.qrToken === qrToken) || null;
  } catch (err) {
    console.warn("Error getting event by token:", err);
    const demo = getDemoEvents();
    return demo.find(e => e.qrToken === qrToken) || null;
  }
}

export async function updateEvent(id: string, updates: Partial<PGRIEvent>): Promise<void> {
  if (!isFirebaseConfigured() || !db) {
    const demo = getDemoEvents().map(e => e.id === id ? { ...e, ...updates } : e);
    saveDemoEvents(demo);
    return;
  }

  try {
    const ref = doc(db, EVENTS_COLLECTION, id);
    await updateDoc(ref, updates);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `${EVENTS_COLLECTION}/${id}`);
  }
}

export async function regenerateQrToken(id: string): Promise<string> {
  const newToken = generateUniqueToken('PGRI');
  await updateEvent(id, { qrToken: newToken });
  return newToken;
}

export async function deleteEvent(id: string): Promise<void> {
  if (!isFirebaseConfigured() || !db) {
    const demo = getDemoEvents().filter(e => e.id !== id);
    saveDemoEvents(demo);
    return;
  }

  try {
    await deleteDoc(doc(db, EVENTS_COLLECTION, id));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `${EVENTS_COLLECTION}/${id}`);
  }
}

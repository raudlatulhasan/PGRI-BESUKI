import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, onAuthStateChanged, signOut as firebaseSignOut } from 'firebase/auth';
import { 
  getActiveFirebaseConfig, 
  isFirebaseConfigured, 
  saveFirebaseConfig, 
  clearCustomFirebaseConfig,
  initializeFirebase,
  testFirestoreConnection,
  auth as initialAuth,
  db as initialDb
} from './config';
import { FirebaseConfig } from '../types';

export interface PreviewAdminInfo {
  email: string;
  nama: string;
}

interface FirebaseContextType {
  isConfigured: boolean;
  config: FirebaseConfig;
  user: User | null;
  previewAdmin: PreviewAdminInfo | null;
  loadingAuth: boolean;
  isConnected: boolean;
  saveConfig: (newConfig: FirebaseConfig) => void;
  resetConfig: () => void;
  signOut: () => Promise<void>;
  refreshConnection: () => Promise<void>;
  demoMode: boolean;
  setDemoMode: (enabled: boolean) => void;
  loginAsPreviewAdmin: (email?: string, nama?: string) => void;
}

const FirebaseContext = createContext<FirebaseContextType | undefined>(undefined);

const PREVIEW_ADMIN_STORAGE_KEY = 'pgri_preview_admin_session';

export const FirebaseProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [config, setConfig] = useState<FirebaseConfig>(getActiveFirebaseConfig());
  const [isConfigured, setIsConfigured] = useState<boolean>(isFirebaseConfigured(config));
  const [user, setUser] = useState<User | null>(null);
  const [previewAdmin, setPreviewAdmin] = useState<PreviewAdminInfo | null>(() => {
    if (typeof window !== 'undefined') {
      try {
        const stored = localStorage.getItem(PREVIEW_ADMIN_STORAGE_KEY);
        if (stored) return JSON.parse(stored);
      } catch {
        // Fallback
      }
    }
    return null;
  });
  const [loadingAuth, setLoadingAuth] = useState<boolean>(true);
  const [isConnected, setIsConnected] = useState<boolean>(navigator.onLine);
  const [demoMode, setDemoModeState] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('pgri_attendance_demo_mode') === 'true';
    }
    return false;
  });

  const setDemoMode = (enabled: boolean) => {
    setDemoModeState(enabled);
    if (typeof window !== 'undefined') {
      localStorage.setItem('pgri_attendance_demo_mode', enabled ? 'true' : 'false');
    }
  };

  const loginAsPreviewAdmin = (email: string = 'admin@pgribesuki.id', nama: string = 'Administrator PGRI Besuki') => {
    const info: PreviewAdminInfo = { email, nama };
    setPreviewAdmin(info);
    if (typeof window !== 'undefined') {
      localStorage.setItem(PREVIEW_ADMIN_STORAGE_KEY, JSON.stringify(info));
    }
  };

  useEffect(() => {
    const handleOnline = () => setIsConnected(true);
    const handleOffline = () => setIsConnected(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    const ready = isFirebaseConfigured(config);
    setIsConfigured(ready);

    if (!ready) {
      setUser(null);
      setLoadingAuth(false);
      return;
    }

    const { auth, db } = initializeFirebase();

    if (db) {
      testFirestoreConnection(db).then((online) => {
        setIsConnected(online && navigator.onLine);
      });
    }

    if (auth) {
      const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
        setUser(currentUser);
        setLoadingAuth(false);
      }, (error) => {
        console.error("Auth state change error:", error);
        setLoadingAuth(false);
      });
      return () => unsubscribe();
    } else {
      setLoadingAuth(false);
    }
  }, [config]);

  const saveConfig = (newConfig: FirebaseConfig) => {
    saveFirebaseConfig(newConfig);
    setConfig(newConfig);
    setIsConfigured(isFirebaseConfigured(newConfig));
    // Re-initialize firebase app instance
    window.location.reload();
  };

  const resetConfig = () => {
    clearCustomFirebaseConfig();
    const defaultConfig = getActiveFirebaseConfig();
    setConfig(defaultConfig);
    setIsConfigured(isFirebaseConfigured(defaultConfig));
    window.location.reload();
  };

  const signOut = async () => {
    if (initialAuth) {
      await firebaseSignOut(initialAuth);
    }
    setUser(null);
    setPreviewAdmin(null);
    if (typeof window !== 'undefined') {
      localStorage.removeItem(PREVIEW_ADMIN_STORAGE_KEY);
    }
  };

  const refreshConnection = async () => {
    const { db } = initializeFirebase();
    if (db) {
      const online = await testFirestoreConnection(db);
      setIsConnected(online && navigator.onLine);
    }
  };

  return (
    <FirebaseContext.Provider
      value={{
        isConfigured,
        config,
        user,
        previewAdmin,
        loadingAuth,
        isConnected,
        saveConfig,
        resetConfig,
        signOut,
        refreshConnection,
        demoMode,
        setDemoMode,
        loginAsPreviewAdmin
      }}
    >
      {children}
    </FirebaseContext.Provider>
  );
};

export const useFirebase = () => {
  const context = useContext(FirebaseContext);
  if (!context) {
    throw new Error('useFirebase must be used within a FirebaseProvider');
  }
  return context;
};

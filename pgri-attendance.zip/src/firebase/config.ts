import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getAuth, Auth } from 'firebase/auth';
import { getFirestore, Firestore, doc, getDocFromServer } from 'firebase/firestore';
import { FirebaseConfig } from '../types';
import autoConfig from '../../firebase-applet-config.json';

export const PLACEHOLDER_CONFIG: FirebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};

const STORAGE_KEY = 'pgri_attendance_firebase_config';

export function getActiveFirebaseConfig(): FirebaseConfig {
  // 1. First priority: Automatic provisioned config from firebase-applet-config.json
  if (autoConfig && autoConfig.apiKey && !autoConfig.apiKey.includes('YOUR_API_KEY')) {
    return autoConfig as unknown as FirebaseConfig;
  }

  // 2. Check localStorage for user-provided configuration
  if (typeof window !== 'undefined') {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed.apiKey && parsed.projectId && !parsed.apiKey.includes('YOUR_API_KEY')) {
          return parsed;
        }
      }
    } catch {
      // Fallback
    }
  }

  // 3. Check Vite environment variables if provided
  const envConfig: FirebaseConfig = {
    apiKey: import.meta.env.VITE_FIREBASE_API_KEY || PLACEHOLDER_CONFIG.apiKey,
    authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || PLACEHOLDER_CONFIG.authDomain,
    projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || PLACEHOLDER_CONFIG.projectId,
    storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || PLACEHOLDER_CONFIG.storageBucket,
    messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || PLACEHOLDER_CONFIG.messagingSenderId,
    appId: import.meta.env.VITE_FIREBASE_APP_ID || PLACEHOLDER_CONFIG.appId
  };

  if (envConfig.apiKey && !envConfig.apiKey.includes('YOUR_API_KEY')) {
    return envConfig;
  }

  return PLACEHOLDER_CONFIG;
}

export function saveFirebaseConfig(config: FirebaseConfig): void {
  if (typeof window !== 'undefined') {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
  }
}

export function clearCustomFirebaseConfig(): void {
  if (typeof window !== 'undefined') {
    localStorage.removeItem(STORAGE_KEY);
  }
}

export function isFirebaseConfigured(config: FirebaseConfig = getActiveFirebaseConfig()): boolean {
  if (!config.apiKey || !config.projectId) return false;
  if (config.apiKey.includes('YOUR_API_KEY') || config.projectId.includes('YOUR_PROJECT_ID')) {
    return false;
  }
  return true;
}

let appInstance: FirebaseApp | null = null;
let authInstance: Auth | null = null;
let dbInstance: Firestore | null = null;

export function initializeFirebase() {
  const config = getActiveFirebaseConfig();
  
  if (!isFirebaseConfigured(config)) {
    return { app: null, auth: null, db: null, isReady: false };
  }

  try {
    if (!getApps().length) {
      appInstance = initializeApp(config);
    } else {
      appInstance = getApp();
    }

    authInstance = getAuth(appInstance);
    // CRITICAL: When firestoreDatabaseId is provided, pass it to getFirestore
    if (config.firestoreDatabaseId) {
      dbInstance = getFirestore(appInstance, config.firestoreDatabaseId);
    } else {
      dbInstance = getFirestore(appInstance);
    }

    return {
      app: appInstance,
      auth: authInstance,
      db: dbInstance,
      isReady: true
    };
  } catch (err) {
    console.error("Gagal menginisialisasi Firebase SDK:", err);
    return { app: null, auth: null, db: null, isReady: false, error: err };
  }
}

export const { app, auth, db } = initializeFirebase();

// Operation types for standard error handling
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const currentAuth = authInstance || (appInstance ? getAuth(appInstance) : null);
  const currentUser = currentAuth?.currentUser;
  
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: currentUser?.uid,
      email: currentUser?.email,
      emailVerified: currentUser?.emailVerified,
      isAnonymous: currentUser?.isAnonymous,
      tenantId: currentUser?.tenantId,
      providerInfo: currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Connection test helper as mandated by skill
export async function testFirestoreConnection(database: Firestore): Promise<boolean> {
  try {
    await getDocFromServer(doc(database, 'system', 'connection_test'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn("Klien offline atau belum terhubung ke Firebase:", error.message);
      return false;
    }
    // Any other response like permission-denied or doc not found means the network connection reached Firebase!
    return true;
  }
}

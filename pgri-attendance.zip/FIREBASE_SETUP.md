# Panduan Setup Google Firebase - PGRI ATTENDANCE

Panduan langkah demi langkah untuk mengaktifkan Google Firebase (Authentication & Cloud Firestore) untuk aplikasi **PGRI ATTENDANCE (Sistem Daftar Hadir Online PGRI Berbasis Barcode)**.

Panduan ini disusun dalam Bahasa Indonesia sederhana agar mudah dipahami bahkan oleh pengguna yang belum terbiasa dengan pemrograman.

---

## 1. Membuat Project Firebase Baru

1. Buka browser Anda dan kunjungi konsol resmi Firebase: [https://console.firebase.google.com/](https://console.firebase.google.com/)
2. Masuk (Login) menggunakan akun Google Anda (Gmail).
3. Klik tombol **"Add project"** atau **"Tambahkan project"**.

---

## 2. Memberi Nama Project

1. Masukkan nama project, misalnya: `pgri-attendance` atau `pgri-kehadiran-online`.
2. Klik **Continue**.
3. Pada opsi *Google Analytics*, Anda bisa memilih menonaktifkannya (atau biarkan aktif jika diinginkan), lalu klik **Create project**.
4. Tunggu beberapa detik hingga proses pembuatan selesai, lalu klik **Continue**.

---

## 3. Mendaftarkan Aplikasi Web & Mendapatkan Konfigurasi

1. Di halaman utama dashboard project Firebase Anda, klik ikon web **`</>`** (Web App).
2. Masukkan nama panggilan aplikasi (App nickname), misalnya: `PGRI Web App`.
3. Opsi *Firebase Hosting* bisa dicentang jika ingin langsung disiapkan, atau lewati dulu.
4. Klik **Register app**.
5. Anda akan melihat blok kode konfigurasi Firebase berupa:

```javascript
const firebaseConfig = {
  apiKey: "AIzaSy...",
  authDomain: "pgri-attendance.firebaseapp.com",
  projectId: "pgri-attendance",
  storageBucket: "pgri-attendance.appspot.com",
  messagingSenderId: "1234567890",
  appId: "1:1234567890:web:abcdef123456"
};
```

6. Salin (copy) data ini. Anda akan memasukkannya ke dalam file konfigurasi atau langsung di menu **Pengaturan Firebase** pada aplikasi PGRI ATTENDANCE.

---

## 4. Mengaktifkan Firestore Database

1. Pada menu sebelah kiri konsol Firebase, buka menu **Build** > **Firestore Database**.
2. Klik tombol **Create database**.
3. Pilih lokasi database: pilih yang terdekat dengan Indonesia, misalnya **asia-southeast1 (Singapore)** atau **asia-southeast2 (Jakarta)**.
4. Pada pilihan aturan keamanan awal, pilih **Start in test mode** atau **Start in production mode** (nanti kita akan memasang Firestore Rules resmi PGRI).
5. Klik **Create** / **Enable**. Tunggu hingga database siap.

---

## 5. Mengaktifkan Firebase Authentication

1. Pada menu sebelah kiri, klik **Build** > **Authentication**.
2. Klik tombol **Get started**.
3. Di tab **Sign-in method**, klik opsi **Email/Password**.
4. Aktifkan toggle **Email/Password** menjadi **Enabled**.
5. Biarkan opsi *Email link (passwordless)* nonaktif.
6. Klik tombol **Save**.

---

## 6. Membuat Akun Admin PGRI Pertama

1. Masih di halaman **Authentication**, pindah ke tab **Users**.
2. Klik tombol **Add user** (Tambahkan pengguna).
3. Masukkan Email admin, misalnya: `admin.pgri@gmail.com` atau email resmi pengurus PGRI Anda.
4. Masukkan Password yang kuat (minimal 6 karakter).
5. Klik **Add user**. Akun admin ini siap digunakan untuk login di aplikasi.

---

## 7. Memasukkan Firebase Config ke Aplikasi

Ada dua cara mudah memasukkan konfigurasi:

### Cara A: Melalui Menu Pengaturan di Tampilan Aplikasi (Paling Mudah)
1. Buka aplikasi PGRI ATTENDANCE di browser Anda.
2. Jika konfigurasi belum diisi, aplikasi akan menampilkan banner / notifikasi:
   *«Firebase belum dikonfigurasi. Silakan masukkan konfigurasi Firebase pada file konfigurasi aplikasi.»*
3. Klik tombol **"Buka Pengaturan Firebase"** di aplikasi.
4. Masukkan `apiKey`, `authDomain`, `projectId`, `storageBucket`, `messagingSenderId`, dan `appId` milik Anda.
5. Klik **Simpan Konfigurasi**. Aplikasi akan otomatis terhubung ke project Firebase Anda.

### Cara B: Melalui File `src/firebase-config.ts`
Buka file `src/firebase-config.ts` di editor Anda, lalu gantikan nilai placeholder:
```typescript
export const defaultFirebaseConfig = {
  apiKey: "API_KEY_ANDA_DARI_FIREBASE",
  authDomain: "PROJECT_ID_ANDA.firebaseapp.com",
  projectId: "PROJECT_ID_ANDA",
  storageBucket: "PROJECT_ID_ANDA.appspot.com",
  messagingSenderId: "NOMOR_SENDER_ANDA",
  appId: "APP_ID_ANDA"
};
```

---

## 8. Mengatur Firestore Security Rules

Agar data kegiatan dan kehadiran peserta aman dari akses liar namun tetap memudahkan peserta mengisi absensi:

1. Di Firebase Console, buka **Firestore Database** > tab **Rules**.
2. Buka file `firestore.rules` yang disediakan dalam proyek ini.
3. Salin seluruh isi file `firestore.rules` dan tempelkan (paste) ke editor Rules di Firebase Console.
4. Klik tombol **Publish**.

*Catatan Keamanan:*
- Peserta hanya dapat mencatat kehadiran jika kegiatan berstatus **"Aktif"**.
- Peserta **tidak dapat** melihat atau mengedit daftar peserta lain.
- Sistem menolak absensi ganda (kombinasi eventId + nomor peserta).
- Admin yang login memiliki hak penuh untuk mengelola kegiatan, melihat peserta, mengedit kesalahan data, dan mengunduh laporan PDF.

---

## 9. Menjalankan Aplikasi Secara Lokal

Jalankan perintah berikut pada terminal:
```bash
npm install
npm run dev
```
Buka browser di alamat: `http://localhost:3000`

---

## 10. Pengujian Aplikasi (Checklist)

1. **Login Admin:**
   - Masuk ke menu **Login Admin PGRI** dengan email dan password yang telah dibuat di langkah 6.
2. **Buat Kegiatan:**
   - Masuk ke menu **Buat Kegiatan** (misal: *"Rapat Kerja PGRI Cabang Besuki"*).
   - Isi tanggal, waktu, lokasi, lalu klik **Simpan Kegiatan**.
3. **Generate QR Code:**
   - Lihat QR Code otomatis yang dihasilkan.
   - Uji tombol **Copy Link** atau **Download QR**.
4. **Uji Absensi Peserta:**
   - Buka link absensi di tab baru atau scan via kamera HP Android.
   - Isi form: Nomor (misal `001`), Nama Lengkap, Asal Sekolah, Jabatan PGRI.
   - Klik **HADIR**.
   - Pastikan muncul konfirmasi berhasil: *«Alhamdulillah, data kehadiran Anda berhasil dicatat.»*
5. **Cek Dashboard & Realtime:**
   - Buka dashboard Admin, pastikan jumlah peserta hadir bertambah secara realtime.
6. **Cetak PDF:**
   - Buka menu **Laporan**, pilih kegiatan, lalu klik **DOWNLOAD PDF**.
   - Periksa file PDF format A4 lengkap dengan kop PGRI, daftar tabel, dan kolom tanda tangan.

---

## 11. Cara Deploy ke Firebase Hosting (Opsional)

Jika ingin mempublikasikan aplikasi secara online gratis dengan domain `*.web.app`:

1. Install Firebase CLI jika belum ada:
   ```bash
   npm install -g firebase-tools
   ```
2. Login ke Firebase:
   ```bash
   firebase login
   ```
3. Build proyek:
   ```bash
   npm run build
   ```
4. Inisialisasi Firebase Hosting:
   ```bash
   firebase init hosting
   ```
   - Pilih project Firebase yang sudah Anda buat.
   - Public directory: `dist`
   - Configure as single-page app: `Yes`
   - Overwrite dist/index.html: `No`
5. Deploy:
   ```bash
   firebase deploy --only hosting
   ```
Aplikasi Anda kini sudah aktif di internet dan dapat diakses oleh seluruh guru dan anggota PGRI!
